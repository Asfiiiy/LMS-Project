'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { apiService } from '@/app/services/api';

interface CourseDetailResponse {
  success: boolean;
  course: any;
  files: any[];
  assignments: any[];
  quizzes: any[];
}

const CourseDetailPage = () => {
  const params = useParams();
  const router = useRouter();
  const courseId = Number(params?.id);
  const [data, setData] = useState<CourseDetailResponse | null>(null);
  const [outline, setOutline] = useState<any>({ units: [] });
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});
  const [pdfSrc, setPdfSrc] = useState<string>('');
  const [pdfLoading, setPdfLoading] = useState(false);
  const [pdfError, setPdfError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!courseId) return;
    (async () => {
      try {
        setLoading(true);
        const [res, ol] = await Promise.all([
          apiService.getCourseDetail(courseId),
          apiService.getCourseOutline(courseId)
        ]);
        if (res.success) {
          setData(res);
        } else {
          setError(res.message || 'Failed to load course');
        }
        if (ol.success) setOutline(ol);
      } catch (e) {
        setError('Failed to load course');
      } finally {
        setLoading(false);
      }
    })();
  }, [courseId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#11CCEF] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <div className="text-gray-600 font-medium">Loading course content...</div>
        </div>
      </div>
    );
  }

  if (error || !data?.course) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-4xl mx-auto bg-white rounded-lg border border-gray-200 p-8 text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">⚠️</span>
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Course Not Available</h2>
          <p className="text-gray-600 mb-6">{error || 'The requested course could not be found.'}</p>
          <button
            onClick={() => router.back()}
            className="px-6 py-3 bg-gray-900 text-white rounded-lg font-medium hover:bg-gray-800 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  const { course, files, assignments, quizzes } = data;

  const getFileUrl = (file: any) => {
    let path = String(file.file_path || '').trim();
    if (path.includes('http://localhost:5000/http')) {
      path = path.replace('http://localhost:5000/', '');
    }
    if (path.startsWith('http://') || path.startsWith('https://')) {
      const fileName = String(file.file_name || file.title || '').toLowerCase();
      if (path.includes('cloudinary.com') && fileName.endsWith('.pdf') && path.includes('/image/upload/')) {
        path = path.replace('/image/upload/', '/raw/upload/');
      }
      return path;
    }
    return `http://localhost:5000/${path.replace(/^\//, '')}`;
  };

  const isPdfFile = (file: any) => {
    const filePath = String(file.file_path || '').toLowerCase();
    const fileName = String(file.file_name || file.title || '').toLowerCase();
    return filePath.endsWith('.pdf') || 
           fileName.endsWith('.pdf') || 
           (filePath.includes('cloudinary') && fileName.includes('.pdf'));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Course Header */}
        <div className="bg-white rounded-xl border border-gray-200 p-8">
          <div className="flex justify-between items-start mb-6">
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{course.title}</h1>
              <p className="text-gray-600 text-lg leading-relaxed mb-6">{course.description}</p>
              <div className="flex flex-wrap gap-3">
                <span className="px-4 py-2 bg-[#11CCEF] text-white rounded-lg text-sm font-medium">
                  {course.category_name || 'Uncategorized'}
                </span>
                <span className={`px-4 py-2 rounded-lg text-sm font-medium ${
                  course.status === 'Active' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {course.status}
                </span>
                <span className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm">
                  Created by: {course.created_by_name}
                </span>
              </div>
            </div>
            <button
              onClick={() => router.back()}
              className="ml-6 px-6 py-3 bg-gray-900 text-white rounded-lg font-medium hover:bg-gray-800 transition-colors flex items-center gap-2"
            >
              <span>←</span>
              Back to Courses
            </button>
          </div>
        </div>

        {/* Course Content */}
        <div className="bg-white rounded-xl border border-gray-200 p-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-semibold text-gray-900">Course Content</h2>
            <button
              onClick={() => {
                const allExpanded = outline.units?.every((u: any) => expanded[u.id]);
                const newExpanded: Record<number, boolean> = {};
                outline.units?.forEach((u: any) => {
                  newExpanded[u.id] = !allExpanded;
                });
                setExpanded(newExpanded);
              }}
              className="px-5 py-2.5 bg-[#11CCEF] text-white rounded-lg font-medium hover:bg-[#0daed9] transition-colors"
            >
              {outline.units?.every((u: any) => expanded[u.id]) ? 'Collapse All' : 'Expand All'}
            </button>
          </div>

          {outline.units?.length ? (
            <div className="space-y-4">
              {outline.units.map((unit: any) => (
                <div
                  key={unit.id}
                  className="border border-gray-200 rounded-xl overflow-hidden transition-colors hover:border-gray-300"
                >
                  <button
                    onClick={() => setExpanded(prev => ({ ...prev, [unit.id]: !prev[unit.id] }))}
                    className="w-full text-left p-6 flex justify-between items-center bg-white hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-[#11CCEF] rounded-lg flex items-center justify-center text-white font-semibold">
                        {unit.order || '•'}
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{unit.title}</h3>
                        <p className="text-sm text-gray-500 mt-1">
                          {[
                            unit.resources?.length > 0 && `${unit.resources.length} resource${unit.resources.length !== 1 ? 's' : ''}`,
                            unit.assignments?.length > 0 && `${unit.assignments.length} assignment${unit.assignments.length !== 1 ? 's' : ''}`,
                            unit.quizzes?.length > 0 && `${unit.quizzes.length} quiz${unit.quizzes.length !== 1 ? 'zes' : ''}`
                          ].filter(Boolean).join(' • ')}
                        </p>
                      </div>
                    </div>
                    <div className="text-2xl text-[#11CCEF] font-light">
                      {expanded[unit.id] ? '−' : '+'}
                    </div>
                  </button>

                  {expanded[unit.id] && (
                    <div className="border-t border-gray-200 bg-gray-50 p-6 space-y-6">
                      {/* Unit Content */}
                      {unit.content && (
                        <div className="bg-white rounded-lg p-6 border border-gray-200">
                          <h4 className="font-semibold text-gray-900 mb-3">Unit Content</h4>
                          <div className="text-gray-700 leading-relaxed whitespace-pre-line">
                            {unit.content}
                          </div>
                        </div>
                      )}

                      {/* Resources */}
                      {unit.resources?.length > 0 && (
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                            <span className="text-lg">📄</span>
                            Learning Resources
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {unit.resources.map((resource: any) => (
                              <div
                                key={resource.id}
                                className="bg-white rounded-lg border border-gray-200 p-4 flex justify-between items-center hover:shadow-sm transition-shadow"
                              >
                                <div className="flex-1 min-w-0">
                                  <div className="font-medium text-gray-900 truncate">
                                    {resource.title || resource.file_name || 'Resource'}
                                  </div>
                                  <div className="text-sm text-gray-500 mt-1">
                                    {isPdfFile(resource) ? 'PDF Document' : 'Video Resource'}
                                  </div>
                                </div>
                                {isPdfFile(resource) ? (
                                  <button
                                    onClick={() => {
                                      const url = getFileUrl(resource);
                                      setPdfSrc(url);
                                      setPdfLoading(true);
                                      setPdfError(false);
                                      setTimeout(() => setPdfLoading(false), 3000);
                                    }}
                                    className="ml-4 px-4 py-2 bg-[#11CCEF] text-white rounded-lg text-sm font-medium hover:bg-[#0daed9] transition-colors whitespace-nowrap"
                                  >
                                    View PDF
                                  </button>
                                ) : (
                                  <a
                                    href={getFileUrl(resource)}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="ml-4 px-4 py-2 bg-[#11CCEF] text-white rounded-lg text-sm font-medium hover:bg-[#0daed9] transition-colors whitespace-nowrap"
                                  >
                                    Play Video
                                  </a>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Assignments */}
                      {unit.assignments?.length > 0 && (
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                            <span className="text-lg">📝</span>
                            Assignments
                          </h4>
                          <div className="space-y-4">
                            {unit.assignments.map((assignment: any) => (
                              <div
                                key={assignment.id}
                                className="bg-white rounded-lg border border-gray-200 p-5"
                              >
                                <div className="flex justify-between items-start mb-3">
                                  <div>
                                    <h5 className="font-semibold text-gray-900">{assignment.title}</h5>
                                    {assignment.description && (
                                      <p className="text-gray-600 mt-1">{assignment.description}</p>
                                    )}
                                  </div>
                                  <span className="px-3 py-1 bg-[#E51791] text-white rounded-full text-sm font-medium">
                                    Assignment
                                  </span>
                                </div>
                                <div className="flex items-center gap-4">
                                  <label className="text-sm text-gray-700 font-medium">Submit your work:</label>
                                  <input
                                    type="file"
                                    className="text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200"
                                    onChange={async (e) => {
                                      const file = e.target.files?.[0];
                                      if (!file) return;
                                      const user = JSON.parse(localStorage.getItem('lms-user') || 'null');
                                      if (!user?.id) {
                                        alert('Please login to submit assignments');
                                        return;
                                      }
                                      try {
                                        const res = await apiService.submitAssignment(assignment.id, user.id, file);
                                        if (res.success) {
                                          alert('Assignment submitted successfully!');
                                          e.target.value = '';
                                        } else {
                                          alert('Failed to submit assignment');
                                        }
                                      } catch (error) {
                                        alert('Error submitting assignment');
                                      }
                                    }}
                                  />
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Quizzes */}
                      {unit.quizzes?.length > 0 && (
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                            <span className="text-lg">❓</span>
                            Quizzes
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {unit.quizzes.map((quiz: any) => (
                              <div
                                key={quiz.id}
                                className="bg-white rounded-lg border border-gray-200 p-5 flex justify-between items-center hover:shadow-sm transition-shadow"
                              >
                                <div>
                                  <h5 className="font-semibold text-gray-900">{quiz.title}</h5>
                                  <p className="text-sm text-gray-500 mt-1">Test your knowledge</p>
                                </div>
                                <a
                                  href={`/quizzes/${quiz.id}`}
                                  className="px-4 py-2 bg-[#E51791] text-white rounded-lg font-medium hover:bg-[#c3147f] transition-colors whitespace-nowrap"
                                >
                                  Take Quiz
                                </a>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {!unit.content && !unit.resources?.length && !unit.assignments?.length && !unit.quizzes?.length && (
                        <div className="text-center py-8 text-gray-500 bg-white rounded-lg border border-gray-200">
                          <div className="text-lg mb-2">No content available</div>
                          <p className="text-sm">This unit will be updated with learning materials soon.</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
              <div className="text-4xl mb-4">📚</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Course Content Coming Soon</h3>
              <p className="text-gray-600">The course materials are being prepared and will be available shortly.</p>
            </div>
          )}
        </div>
      </div>

      {/* PDF Viewer Modal */}
      {pdfSrc && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-6xl h-[90vh] rounded-xl shadow-2xl overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-white">
              <h3 className="font-semibold text-gray-900">Document Viewer</h3>
              <button
                onClick={() => setPdfSrc('')}
                className="text-gray-400 hover:text-gray-600 text-2xl font-bold w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 bg-gray-100 relative">
              {pdfLoading && !pdfError && (
                <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-90 z-20">
                  <div className="text-center">
                    <div className="w-12 h-12 border-4 border-[#11CCEF] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-gray-600 font-medium">Loading document...</p>
                  </div>
                </div>
              )}
              
              <div className="w-full h-full">
                <iframe
                  key={pdfSrc}
                  src={
                    pdfSrc.includes('cloudinary.com')
                      ? `${apiService.baseUrlPublic}/admin/proxy-pdf?url=${encodeURIComponent(pdfSrc)}`
                      : pdfSrc
                  }
                  className="w-full h-full"
                  title="PDF Viewer"
                  allow="fullscreen"
                  style={{ border: 'none' }}
                  onLoad={() => {
                    setPdfLoading(false);
                    setPdfError(false);
                  }}
                  onError={() => {
                    setPdfLoading(false);
                    setPdfError(true);
                  }}
                />
              </div>

              {pdfError && (
                <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-95 z-10">
                  <div className="text-center p-8">
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl">⚠️</span>
                    </div>
                    <p className="text-lg font-medium text-gray-900 mb-4">
                      Unable to display document
                    </p>
                    <a
                      href={pdfSrc}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-[#11CCEF] text-white rounded-lg font-medium hover:bg-[#0daed9] transition-colors inline-block"
                    >
                      Open in New Tab
                    </a>
                  </div>
                </div>
              )}

              <div className="absolute bottom-4 right-4 z-10">
                <a
                  href={pdfSrc}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-medium hover:bg-gray-800 transition-colors shadow-lg"
                  title="Open document in new tab"
                >
                  Open in New Tab
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CourseDetailPage;