'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

const LogoutPage = () => {
  const router = useRouter();
  const [isLoggingOut, setIsLoggingOut] = useState(true);

  useEffect(() => {
    // Clear all authentication data from localStorage
    localStorage.removeItem('lms-token');
    localStorage.removeItem('lms-user');

    // Dispatch custom events immediately for instant navbar update
    // Events are dispatched synchronously after localStorage is cleared
    window.dispatchEvent(new Event('logout'));
    window.dispatchEvent(new Event('auth-change'));

    // Show logout message for a moment before redirecting
    const timer = setTimeout(() => {
      setIsLoggingOut(false);
      router.push('/login');
    }, 1500);

    return () => clearTimeout(timer);
  }, [router]);

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#D7E5FE' }}>
      <div className="bg-white p-8 rounded-xl shadow-lg w-full max-w-md text-center">
        <div className="mb-6">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-b-4 border-[#11CCEF] mb-4"></div>
        </div>
        <h1 className="text-3xl font-bold mb-4" style={{ color: '#464646' }}>
          {isLoggingOut ? 'Logging out...' : 'Logged out successfully'}
        </h1>
        <p className="text-gray-600 mb-6">
          {isLoggingOut 
            ? 'Please wait while we log you out...' 
            : 'Redirecting to login page...'}
        </p>
        {!isLoggingOut && (
          <div className="flex justify-center">
            <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LogoutPage;

