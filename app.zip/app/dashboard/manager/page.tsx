'use client';

import ProtectedRoute from '@/app/components/ProtectedRoute';
import { useEffect, useState } from 'react';
import { UserRole, User } from '@/app/components/types';

interface Student {
  id: number;
  name: string;
  coursesAssigned: number;
}

const ManagerDashboard = () => {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [students, setStudents] = useState<Student[]>([]);

  useEffect(() => {
    const user: User | null = JSON.parse(localStorage.getItem('lms-user') || 'null');
    setUserRole(user?.role || null);

    // Simulated students under this manager
    const managerStudents: Student[] = [
      { id: 1, name: 'John Doe', coursesAssigned: 3 },
      { id: 2, name: 'Jane Smith', coursesAssigned: 2 },
      { id: 3, name: 'Alex Johnson', coursesAssigned: 4 },
    ];
    setStudents(managerStudents);
  }, []);

  return (
    <ProtectedRoute allowedRoles={['Manager']} userRole={userRole}>
      <div className="p-8 bg-gray-100 min-h-screen">
        <h1 className="text-3xl font-bold mb-6">Manager Dashboard</h1>

        {/* Students Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {students.map(student => (
            <div key={student.id} className="bg-white p-6 rounded shadow-md">
              <h2 className="text-xl font-semibold mb-2">{student.name}</h2>
              <p>Assigned Courses: {student.coursesAssigned}</p>
              <button className="mt-3 px-4 py-2 bg-[#11CCEF] text-white rounded hover:bg-[#0daed9]">
                View Student
              </button>
            </div>
          ))}
        </div>

        {/* Manager Actions */}
        <div className="bg-white p-6 rounded shadow-md">
          <h2 className="text-2xl font-semibold mb-4">Manager Actions</h2>
          <ul className="space-y-3">
            <li>
              <button className="px-4 py-2 bg-[#E51791] text-white rounded hover:bg-[#c3147f]">
                Assign Courses to Students
              </button>
            </li>
            <li>
              <button className="px-4 py-2 bg-[#11CCEF] text-white rounded hover:bg-[#0daed9]">
                View Students’ Progress
              </button>
            </li>
            <li>
              <button className="px-4 py-2 bg-[#464646] text-white rounded hover:bg-[#333]">
                Chat with Students
              </button>
            </li>
          </ul>
        </div>
      </div>
    </ProtectedRoute>
  );
};

export default ManagerDashboard;
