'use client';

import ProtectedRoute from '@/app/components/ProtectedRoute';
import { useEffect, useState } from 'react';
import { UserRole, User } from '@/app/components/types';

interface Announcement {
  id: number;
  title: string;
  content: string;
}

const ModeratorDashboard = () => {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);

  useEffect(() => {
    const user: User | null = JSON.parse(localStorage.getItem('lms-user') || 'null');
    setUserRole(user?.role || null);

    // Simulated announcements (replace with API)
    const siteAnnouncements: Announcement[] = [
      { id: 1, title: 'Site Maintenance', content: 'The LMS will be down from 2 AM to 4 AM.' },
      { id: 2, title: 'Forum Guidelines', content: 'Please follow forum rules while posting.' },
    ];
    setAnnouncements(siteAnnouncements);
  }, []);

  return (
    <ProtectedRoute allowedRoles={['Moderator']} userRole={userRole}>
      <div className="p-8 bg-gray-100 min-h-screen">
        <h1 className="text-3xl font-bold mb-6">Moderator Dashboard</h1>

        {/* Announcements Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {announcements.map(a => (
            <div key={a.id} className="bg-white p-4 rounded shadow-md hover:shadow-lg transition">
              <h2 className="text-xl font-semibold mb-2">{a.title}</h2>
              <p className="text-gray-600">{a.content}</p>
              <div className="mt-3 flex space-x-2">
                <button className="px-3 py-1 bg-[#11CCEF] text-white rounded hover:bg-[#0daed9]">
                  Comment
                </button>
                <button className="px-3 py-1 bg-[#E51791] text-white rounded hover:bg-[#c3147f]">
                  Moderate Post
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="bg-white p-6 rounded shadow-md">
          <h2 className="text-2xl font-semibold mb-4">Moderator Actions</h2>
          <ul className="space-y-3">
            <li>
              <button className="px-4 py-2 bg-[#11CCEF] text-white rounded hover:bg-[#0daed9]">
                Create Site Announcement
              </button>
            </li>
            <li>
              <button className="px-4 py-2 bg-[#E51791] text-white rounded hover:bg-[#c3147f]">
                Moderate Forums
              </button>
            </li>
            <li>
              <button className="px-4 py-2 bg-[#464646] text-white rounded hover:bg-[#333]">
                Notifications
              </button>
            </li>
          </ul>
        </div>
      </div>
    </ProtectedRoute>
  );
};

export default ModeratorDashboard;
