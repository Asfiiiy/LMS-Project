'use client';

import ProtectedRoute from '@/app/components/ProtectedRoute';
import UserManagement from '@/app/components/UserManagement';
import CourseManagement from '@/app/components/CourseManagement';
import StudentEnrollment from '@/app/components/StudentEnrollment';
import { apiService } from '@/app/services/api';
import { useEffect, useState } from 'react';
import { UserRole, User } from '@/app/components/types';

interface DashboardStats {
  users: Array<{ role: string; count: number }>;
  courses: { total_courses: number; active_courses: number };
  assignments: { total_assignments: number };
  quizzes: { total_quizzes: number };
}

const AdminDashboard = () => {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [user, setUser] = useState<User | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    const userData: User | null = JSON.parse(localStorage.getItem('lms-user') || 'null');
    setUser(userData);
    setUserRole(userData?.role || null);
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const data = await apiService.getAdminStats();
      if (data.success) {
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'overview', name: 'Overview', icon: '📊' },
    { id: 'users', name: 'User Management', icon: '👥' },
    { id: 'courses', name: 'Course Management', icon: '📚' },
    { id: 'enrollment', name: 'Enroll Students', icon: '➕' },
    { id: 'assignments', name: 'Assignments', icon: '📝' },
    { id: 'quizzes', name: 'Quizzes', icon: '❓' },
    { id: 'forums', name: 'Forums', icon: '💬' },
    { id: 'certificates', name: 'Certificates', icon: '🏆' },
    { id: 'reports', name: 'Reports', icon: '📈' }
  ];

  const getRoleColor = (role: string) => {
    switch (role.toLowerCase()) {
      case 'admin': return 'bg-red-500';
      case 'tutor': return 'bg-green-500';
      case 'student': return 'bg-blue-500';
      case 'manager': return 'bg-purple-500';
      case 'moderator': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <ProtectedRoute allowedRoles={['Admin']} userRole={userRole}>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="px-8 py-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-gray-600 mt-1">Complete system management and control</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#11CCEF] rounded-lg flex items-center justify-center text-white font-semibold">
                  A
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex">
          {/* Sidebar */}
          <div className="w-64 bg-white shadow-sm min-h-screen border-r border-gray-200">
            <nav className="p-4">
              <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">
                Navigation
              </h2>
              <ul className="space-y-1">
                {tabs.map((tab) => (
                  <li key={tab.id}>
                    <button
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full text-left px-4 py-3 rounded-lg transition-colors flex items-center gap-3 ${
                        activeTab === tab.id
                          ? 'bg-[#11CCEF] text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <span className="text-lg">{tab.icon}</span>
                      <span className="font-medium">{tab.name}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6">
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="text-gray-600">Loading dashboard data...</div>
              </div>
            ) : (
              <>
                {/* Overview Tab */}
                {activeTab === 'overview' && (
                  <div className="space-y-6">
                    {/* Stats Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                      {stats?.users.map((userStat) => (
                        <div 
                          key={userStat.role} 
                          className="bg-white p-5 rounded-lg shadow-sm border border-gray-200"
                        >
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="text-base font-semibold text-gray-700">{userStat.role}s</h3>
                            <div className={`w-8 h-8 ${getRoleColor(userStat.role)} rounded-lg flex items-center justify-center text-white text-xs font-semibold`}>
                              {userStat.role.charAt(0)}
                            </div>
                          </div>
                          <p className="text-2xl font-bold text-gray-900">{userStat.count}</p>
                        </div>
                      ))}
                      
                      {/* Courses Stats */}
                      <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-base font-semibold text-gray-700">Total Courses</h3>
                          <div className="w-8 h-8 bg-[#E51791] rounded-lg flex items-center justify-center text-white text-xs">
                            📚
                          </div>
                        </div>
                        <p className="text-2xl font-bold text-gray-900">{stats?.courses.total_courses}</p>
                      </div>

                      <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-base font-semibold text-gray-700">Active Courses</h3>
                          <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center text-white text-xs">
                            🎯
                          </div>
                        </div>
                        <p className="text-2xl font-bold text-gray-900">{stats?.courses.active_courses}</p>
                      </div>

                      <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-base font-semibold text-gray-700">Assignments</h3>
                          <div className="w-8 h-8 bg-gray-600 rounded-lg flex items-center justify-center text-white text-xs">
                            📝
                          </div>
                        </div>
                        <p className="text-2xl font-bold text-gray-900">{stats?.assignments.total_assignments}</p>
                      </div>

                      <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-base font-semibold text-gray-700">Quizzes</h3>
                          <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center text-white text-xs">
                            ❓
                          </div>
                        </div>
                        <p className="text-2xl font-bold text-gray-900">{stats?.quizzes.total_quizzes}</p>
                      </div>
                    </div>

                    {/* Quick Actions */}
                    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                      <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <button 
                          onClick={() => setActiveTab('users')}
                          className="p-4 bg-[#11CCEF] text-white rounded-lg hover:bg-[#0daed9] transition-colors text-left"
                        >
                          <div className="text-xl mb-2">👥</div>
                          <div className="font-semibold">Manage Users</div>
                          <div className="text-sm opacity-90 mt-1">User management</div>
                        </button>
                        <button 
                          onClick={() => setActiveTab('courses')}
                          className="p-4 bg-[#E51791] text-white rounded-lg hover:bg-[#c3147f] transition-colors text-left"
                        >
                          <div className="text-xl mb-2">📚</div>
                          <div className="font-semibold">Manage Courses</div>
                          <div className="text-sm opacity-90 mt-1">Course management</div>
                        </button>
                        <button 
                          onClick={() => setActiveTab('assignments')}
                          className="p-4 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-left"
                        >
                          <div className="text-xl mb-2">📝</div>
                          <div className="font-semibold">Assignments</div>
                          <div className="text-sm opacity-90 mt-1">Assignment management</div>
                        </button>
                        <button 
                          onClick={() => setActiveTab('reports')}
                          className="p-4 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-left"
                        >
                          <div className="text-xl mb-2">📈</div>
                          <div className="font-semibold">Reports</div>
                          <div className="text-sm opacity-90 mt-1">Analytics and insights</div>
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* User Management Tab */}
                {activeTab === 'users' && <UserManagement />}

                {/* Course Management Tab */}
                {activeTab === 'courses' && <CourseManagement />}

                {/* Enrollment Tab */}
                {activeTab === 'enrollment' && user && (
                  <StudentEnrollment userId={user.id} />
                )}

                {/* Other tabs will be implemented */}
                {activeTab !== 'overview' && activeTab !== 'users' && activeTab !== 'courses' && activeTab !== 'enrollment' && (
                  <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <h2 className="text-xl font-semibold text-gray-900 mb-4">
                      {tabs.find(tab => tab.id === activeTab)?.name}
                    </h2>
                    <div className="text-center py-8">
                      <div className="text-4xl mb-4">🚧</div>
                      <p className="text-gray-600">
                        {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} management coming soon...
                      </p>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
};

export default AdminDashboard;