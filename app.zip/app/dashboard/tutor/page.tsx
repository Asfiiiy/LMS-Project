'use client';

import ProtectedRoute from '@/app/components/ProtectedRoute';
import CourseManagement from '@/app/components/CourseManagement';
import StudentEnrollment from '@/app/components/StudentEnrollment';
import { useEffect, useState } from 'react';
import { UserRole, User } from '@/app/components/types';
import { apiService } from '@/app/services/api';

interface Course {
  id: number;
  title: string;
  description: string;
  status: string;
  student_count: number;
  assignment_count: number;
  quiz_count: number;
  created_at: string;
}

interface Student {
  id: number;
  name: string;
  email: string;
  course_id: number;
  course_title: string;
}

interface Assignment {
  id: number;
  title: string;
  description: string;
  due_date: string;
  course_title: string;
  submission_count: number;
  graded_count: number;
}

interface Quiz {
  id: number;
  title: string;
  course_title: string;
  submission_count: number;
}

interface Stats {
  courses: number;
  students: number;
  assignments: number;
  quizzes: number;
  pendingGrading: number;
}

const TutorDashboard = () => {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [user, setUser] = useState<User | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedAssignment, setSelectedAssignment] = useState<number | null>(null);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [gradingData, setGradingData] = useState<Record<number, { grade: string; feedback: string }>>({});

  useEffect(() => {
    const userData: User | null = JSON.parse(localStorage.getItem('lms-user') || 'null');
    setUser(userData);
    setUserRole(userData?.role || null);
    
    if (userData?.id) {
      fetchDashboardData(userData.id);
    }
  }, []);

  const fetchDashboardData = async (tutorId: number) => {
    try {
      setLoading(true);
      const [statsData, coursesData, studentsData, assignmentsData, quizzesData] = await Promise.all([
        apiService.getTutorStats(tutorId),
        apiService.getTutorCourses(tutorId),
        apiService.getTutorStudents(tutorId),
        apiService.getTutorAssignments(tutorId),
        apiService.getTutorQuizzes(tutorId)
      ]);

      if (statsData.success) setStats(statsData.stats);
      if (coursesData.success) setCourses(coursesData.courses);
      if (studentsData.success) {
        setStudents(studentsData.students || []);
      } else {
        console.error('Error fetching students:', studentsData.message);
        setStudents([]);
      }
      if (assignmentsData.success) setAssignments(assignmentsData.assignments);
      if (quizzesData.success) setQuizzes(quizzesData.quizzes);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSubmissions = async (assignmentId: number) => {
    if (!user?.id) return;
    try {
      const data = await apiService.getAssignmentSubmissions(user.id, assignmentId);
      if (data.success) {
        setSubmissions(data.submissions);
        setSelectedAssignment(assignmentId);
      }
    } catch (error) {
      console.error('Error fetching submissions:', error);
      alert('Error fetching submissions');
    }
  };

  const handleGradeSubmission = async (submissionId: number) => {
    if (!user?.id) return;
    const gradeData = gradingData[submissionId];
    if (!gradeData?.grade) {
      alert('Please enter a grade');
      return;
    }
    try {
      const data = await apiService.gradeSubmission(
        submissionId,
        user.id,
        gradeData.grade,
        gradeData.feedback
      );
      if (data.success) {
        alert('Grade submitted successfully!');
        if (selectedAssignment) {
          fetchSubmissions(selectedAssignment);
        }
        setGradingData({ ...gradingData, [submissionId]: { grade: '', feedback: '' } });
      }
    } catch (error) {
      console.error('Error grading submission:', error);
      alert('Error grading submission');
    }
  };

  const tabs = [
    { id: 'overview', name: 'Overview', icon: '📊' },
    { id: 'courses', name: 'My Courses', icon: '📚' },
    { id: 'enrollment', name: 'Enroll Students', icon: '➕' },
    { id: 'students', name: 'Students', icon: '👥' },
    { id: 'assignments', name: 'Assignments', icon: '📝' },
    { id: 'quizzes', name: 'Quizzes', icon: '❓' },
  ];

  if (loading) {
    return (
      <ProtectedRoute allowedRoles={['Tutor']} userRole={userRole}>
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-[#11CCEF] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Loading dashboard...</p>
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute allowedRoles={['Tutor']} userRole={userRole}>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="px-8 py-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Tutor Dashboard</h1>
                <p className="text-gray-600 mt-1">Manage your courses, students, and assignments</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center text-white font-semibold">
                  T
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex">
          {/* Sidebar */}
          <div className="w-64 bg-white shadow-sm min-h-screen border-r border-gray-200">
            <nav className="p-4">
              <h2 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">
                Navigation
              </h2>
              <ul className="space-y-1">
                {tabs.map((tab) => (
                  <li key={tab.id}>
                    <button
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full text-left px-4 py-3 rounded-lg transition-colors flex items-center gap-3 ${
                        activeTab === tab.id
                          ? 'bg-[#11CCEF] text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <span className="text-lg">{tab.icon}</span>
                      <span className="font-medium">{tab.name}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1 p-6">
            {/* Overview Tab */}
            {activeTab === 'overview' && stats && (
              <div className="space-y-6">
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5">
                  <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-semibold text-gray-700">My Courses</h3>
                      <div className="w-8 h-8 bg-[#E51791] rounded-lg flex items-center justify-center text-white text-xs">
                        📚
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{stats.courses}</p>
                  </div>

                  <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-semibold text-gray-700">Students</h3>
                      <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center text-white text-xs">
                        👥
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{stats.students}</p>
                  </div>

                  <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-semibold text-gray-700">Assignments</h3>
                      <div className="w-8 h-8 bg-gray-600 rounded-lg flex items-center justify-center text-white text-xs">
                        📝
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{stats.assignments}</p>
                  </div>

                  <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-semibold text-gray-700">Quizzes</h3>
                      <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center text-white text-xs">
                        ❓
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{stats.quizzes}</p>
                  </div>

                  <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-base font-semibold text-gray-700">Pending Grading</h3>
                      <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center text-white text-xs">
                        ⏳
                      </div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{stats.pendingGrading}</p>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <button 
                      onClick={() => setActiveTab('courses')}
                      className="p-4 bg-[#11CCEF] text-white rounded-lg hover:bg-[#0daed9] transition-colors text-left"
                    >
                      <div className="text-xl mb-2">📚</div>
                      <div className="font-semibold">Manage Courses</div>
                      <div className="text-sm opacity-90 mt-1">View & manage your courses</div>
                    </button>
                    <button 
                      onClick={() => setActiveTab('assignments')}
                      className="p-4 bg-[#E51791] text-white rounded-lg hover:bg-[#c3147f] transition-colors text-left"
                    >
                      <div className="text-xl mb-2">📝</div>
                      <div className="font-semibold">Grade Assignments</div>
                      <div className="text-sm opacity-90 mt-1">Review & grade submissions</div>
                    </button>
                    <button 
                      onClick={() => setActiveTab('students')}
                      className="p-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-left"
                    >
                      <div className="text-xl mb-2">👥</div>
                      <div className="font-semibold">View Students</div>
                      <div className="text-sm opacity-90 mt-1">See all your students</div>
                    </button>
                    <button 
                      onClick={() => setActiveTab('quizzes')}
                      className="p-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-left"
                    >
                      <div className="text-xl mb-2">❓</div>
                      <div className="font-semibold">Manage Quizzes</div>
                      <div className="text-sm opacity-90 mt-1">View quiz submissions</div>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Courses Tab - Reuse CourseManagement Component */}
            {activeTab === 'courses' && user && (
              <CourseManagement 
                role="Tutor" 
                userId={user.id}
                showCategoryManagement={false}
                showBackupRestore={false}
              />
            )}

            {/* Enrollment Tab */}
            {activeTab === 'enrollment' && user && (
              <StudentEnrollment userId={user.id} />
            )}

            {/* Students Tab - Simple view of all students */}
            {activeTab === 'students' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold text-gray-900">Students</h2>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Course</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {students.map((student, index) => (
                          <tr key={`${student.id}-${student.course_id || 'no-course'}-${index}`}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{student.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{student.email}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {student.course_title || <span className="text-gray-400 italic">Not enrolled</span>}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {students.length === 0 && (
                      <div className="text-center py-12">
                        <div className="text-4xl mb-4">👥</div>
                        <p className="text-gray-500">No students found</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Assignments Tab */}
            {activeTab === 'assignments' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold text-gray-900">Assignments & Grading</h2>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900">My Assignments</h3>
                    {assignments.map((assignment) => (
                      <div key={assignment.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-semibold text-gray-900">{assignment.title}</h4>
                          <span className="text-xs text-gray-500">{assignment.course_title}</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{assignment.description}</p>
                        <div className="flex justify-between items-center text-sm text-gray-500 mb-3">
                          <span>📤 {assignment.submission_count || 0} submissions</span>
                          <span>✅ {assignment.graded_count || 0} graded</span>
                          {assignment.due_date && (
                            <span>📅 Due: {new Date(assignment.due_date).toLocaleDateString()}</span>
                          )}
                        </div>
                        <button
                          onClick={() => fetchSubmissions(assignment.id)}
                          className="w-full px-4 py-2 bg-[#E51791] text-white rounded-lg hover:bg-[#c3147f] transition-colors text-sm"
                        >
                          View Submissions
                        </button>
                      </div>
                    ))}
                    {assignments.length === 0 && (
                      <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
                        <div className="text-4xl mb-4">📝</div>
                        <p className="text-gray-500">No assignments created yet</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Grade Submissions</h3>
                    {selectedAssignment && submissions.length > 0 ? (
                      <div className="space-y-4">
                        {submissions.map((submission) => (
                          <div key={submission.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                            <div className="mb-3">
                              <div className="font-semibold text-gray-900">{submission.student_name}</div>
                              <div className="text-sm text-gray-500">{submission.student_email}</div>
                              <div className="text-sm text-gray-500 mt-1">
                                Submitted: {new Date(submission.submitted_at).toLocaleString()}
                              </div>
                              {submission.file_path && (
                                <a
                                  href={submission.file_path}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-sm text-[#11CCEF] hover:underline mt-2 inline-block"
                                >
                                  📎 View Submission
                                </a>
                              )}
                            </div>
                            {submission.grade ? (
                              <div className="bg-green-50 border border-green-200 rounded p-3">
                                <div className="text-sm font-semibold text-green-800">Grade: {submission.grade}</div>
                                {submission.feedback && (
                                  <div className="text-sm text-green-700 mt-1">{submission.feedback}</div>
                                )}
                              </div>
                            ) : (
                              <div className="space-y-2">
                                <input
                                  type="text"
                                  placeholder="Enter grade (e.g., A, B, 85%)"
                                  value={gradingData[submission.id]?.grade || ''}
                                  onChange={(e) => setGradingData({
                                    ...gradingData,
                                    [submission.id]: { ...gradingData[submission.id], grade: e.target.value, feedback: gradingData[submission.id]?.feedback || '' }
                                  })}
                                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                                />
                                <textarea
                                  placeholder="Feedback (optional)"
                                  value={gradingData[submission.id]?.feedback || ''}
                                  onChange={(e) => setGradingData({
                                    ...gradingData,
                                    [submission.id]: { ...gradingData[submission.id], grade: gradingData[submission.id]?.grade || '', feedback: e.target.value }
                                  })}
                                  rows={2}
                                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                                />
                                <button
                                  onClick={() => handleGradeSubmission(submission.id)}
                                  className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                                >
                                  Submit Grade
                                </button>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
                        <div className="text-4xl mb-4">📋</div>
                        <p className="text-gray-500">Select an assignment to view submissions</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Quizzes Tab */}
            {activeTab === 'quizzes' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold text-gray-900">My Quizzes</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {quizzes.map((quiz) => (
                    <div key={quiz.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                      <div className="flex justify-between items-start mb-3">
                        <h3 className="text-lg font-semibold text-gray-900">{quiz.title}</h3>
                        <span className="text-xs text-gray-500">{quiz.course_title}</span>
                      </div>
                      <div className="text-sm text-gray-500 mb-4">
                        📤 {quiz.submission_count || 0} submissions
                      </div>
                      <button
                        onClick={() => {
                          if (user?.id) {
                            apiService.getQuizSubmissions(user.id, quiz.id).then(data => {
                              if (data.success) {
                                alert(`Quiz: ${quiz.title}\nSubmissions: ${data.submissions.length}\n\nView detailed results in quiz management.`);
                              }
                            });
                          }
                        }}
                        className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm"
                      >
                        View Submissions
                      </button>
                    </div>
                  ))}
                  {quizzes.length === 0 && (
                    <div className="col-span-full text-center py-12 bg-white rounded-lg border border-gray-200">
                      <div className="text-4xl mb-4">❓</div>
                      <p className="text-gray-500">No quizzes created yet</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
};

export default TutorDashboard;
