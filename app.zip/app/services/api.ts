// Reusable API service for making HTTP requests
class ApiService {
  private baseUrl: string;
  public readonly baseUrlPublic: string;

  constructor() {
    this.baseUrl = 'http://localhost:5000/api';
    this.baseUrlPublic = 'http://localhost:5000/api';
  }

  private getToken(): string | null {
    if (typeof window === 'undefined') return null;
    try {
      return localStorage.getItem('lms-token');
    } catch {
      return null;
    }
  }

  private getHeaders() {
    const token = this.getToken();
    return {
      'Content-Type': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` })
    };
  }

  private async request(endpoint: string, options: RequestInit = {}) {
    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers: {
          ...this.getHeaders(),
          ...options.headers
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`API Error for ${endpoint}:`, error);
      throw error;
    }
  }

  // Admin API methods
  async getAdminStats() {
    return this.request('/admin/stats');
  }

  async getUsers() {
    return this.request('/admin/users');
  }

  async getRoles() {
    return this.request('/admin/roles');
  }

  async createUser(userData: any) {
    return this.request('/admin/users', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  }

  async updateUser(userId: number, userData: any) {
    return this.request(`/admin/users/${userId}`, {
      method: 'PUT',
      body: JSON.stringify(userData)
    });
  }

  async deleteUser(userId: number) {
    return this.request(`/admin/users/${userId}`, {
      method: 'DELETE'
    });
  }

  async getCourses() {
    return this.request('/admin/courses');
  }

  async createCourse(courseData: any) {
    return this.request('/admin/courses', {
      method: 'POST',
      body: JSON.stringify(courseData)
    });
  }

  async updateCourse(courseId: number, courseData: any) {
    return this.request(`/admin/courses/${courseId}`, {
      method: 'PUT',
      body: JSON.stringify(courseData)
    });
  }

  async deleteCourse(courseId: number) {
    return this.request(`/admin/courses/${courseId}`, {
      method: 'DELETE'
    });
  }

  async getCourseCategories() {
    return this.request('/admin/course-categories');
  }

  async createCourseCategory(categoryData: any) {
    return this.request('/admin/course-categories', {
      method: 'POST',
      body: JSON.stringify(categoryData)
    });
  }

  async getSubCategories(categoryId: number) {
    return this.request(`/admin/sub-categories/${categoryId}`);
  }

  async createSubCategory(subCategoryData: any) {
    return this.request('/admin/sub-categories', {
      method: 'POST',
      body: JSON.stringify(subCategoryData)
    });
  }

  async uploadCourseFile(courseId: number, file: File, fileType: string = 'resource') {
    const formData = new FormData();
    formData.append('courseFile', file);
    formData.append('courseId', courseId.toString());
    formData.append('fileType', fileType);

    return fetch(`${this.baseUrl}/admin/courses/upload`, {
      method: 'POST',
      headers: {
        ...(this.getToken() && { 'Authorization': `Bearer ${this.getToken()}` })
      },
      body: formData
    }).then(response => response.json());
  }

  async getCourseFiles(courseId: number) {
    return this.request(`/admin/courses/${courseId}/files`);
  }

  async getCourseDetail(courseId: number) {
    return this.request(`/admin/courses/${courseId}/detail`);
  }

  async getCourseOutline(courseId: number) {
    return this.request(`/admin/courses/${courseId}/outline`);
  }

  async createUnit(courseId: number, payload: any) {
    return this.request(`/admin/courses/${courseId}/units`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updateUnit(unitId: number, payload: any) {
    return this.request(`/admin/units/${unitId}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async deleteUnit(unitId: number) {
    return this.request(`/admin/units/${unitId}`, {
      method: 'DELETE'
    });
  }

  async uploadUnitResource(unitId: number, file: File) {
    const form = new FormData();
    form.append('file', file);
    return fetch(`${this.baseUrl}/admin/units/${unitId}/resources`, {
      method: 'POST',
      headers: {
        ...(this.getToken() && { 'Authorization': `Bearer ${this.getToken()}` })
      },
      body: form
    }).then(r => r.json());
  }

  async updateResource(resourceId: number, title: string) {
    return this.request(`/admin/resources/${resourceId}`, {
      method: 'PUT',
      body: JSON.stringify({ title })
    });
  }

  async deleteResource(resourceId: number) {
    return this.request(`/admin/resources/${resourceId}`, {
      method: 'DELETE'
    });
  }

  async updateQuiz(quizId: number, title: string) {
    return this.request(`/admin/quizzes/${quizId}`, {
      method: 'PUT',
      body: JSON.stringify({ title })
    });
  }

  async deleteQuiz(quizId: number) {
    return this.request(`/admin/quizzes/${quizId}`, {
      method: 'DELETE'
    });
  }

  async submitAssignment(assignmentId: number, studentId: number, file: File) {
    const form = new FormData();
    form.append('submission', file);
    form.append('student_id', String(studentId));
    return fetch(`${this.baseUrl}/admin/assignments/${assignmentId}/submit`, {
      method: 'POST',
      headers: {
        ...(this.getToken() && { 'Authorization': `Bearer ${this.getToken()}` })
      },
      body: form
    }).then(r => r.json());
  }

  async backupCourses() {
    return this.request('/admin/courses/backup', {
      method: 'POST'
    });
  }

  async restoreCourses(backupFile: File) {
    const formData = new FormData();
    formData.append('backupFile', backupFile);

    return fetch(`${this.baseUrl}/admin/courses/restore`, {
      method: 'POST',
      headers: {
        ...(this.getToken() && { 'Authorization': `Bearer ${this.getToken()}` })
      },
      body: formData
    }).then(response => response.json());
  }

  async getAssignments() {
    return this.request('/admin/assignments');
  }

  async getQuizzes() {
    return this.request('/admin/quizzes');
  }

  async getForums() {
    return this.request('/admin/forums');
  }

  async getCertificates() {
    return this.request('/admin/certificates');
  }

  // Test admin API connection
  async testAdminApi() {
    return this.request('/admin/test');
  }

  // Quiz import (GIFT)
  async importGift(courseId: number, gift: string, title?: string, unitId?: number) {
    return this.request(`/admin/courses/${courseId}/quizzes/import-gift`, {
      method: 'POST',
      body: JSON.stringify({ gift, title, unit_id: unitId })
    });
  }

  async getQuiz(quizId: number) {
    return this.request(`/admin/quizzes/${quizId}`);
  }

  async attemptQuiz(quizId: number, studentId: number, answers: Array<{question_id: number; answer: string;}>) {
    return this.request(`/admin/quizzes/${quizId}/attempt`, {
      method: 'POST',
      body: JSON.stringify({ student_id: studentId, answers })
    });
  }

  // Tutor API methods
  async getTutorCourses(tutorId: number) {
    return this.request(`/admin/tutor/${tutorId}/courses`);
  }

  async getTutorStudents(tutorId: number) {
    return this.request(`/admin/tutor/${tutorId}/students`);
  }

  async getTutorAssignments(tutorId: number) {
    return this.request(`/admin/tutor/${tutorId}/assignments`);
  }

  async getTutorQuizzes(tutorId: number) {
    return this.request(`/admin/tutor/${tutorId}/quizzes`);
  }

  async getTutorStats(tutorId: number) {
    return this.request(`/admin/tutor/${tutorId}/stats`);
  }

  async getAssignmentSubmissions(tutorId: number, assignmentId: number) {
    return this.request(`/admin/tutor/${tutorId}/assignments/${assignmentId}/submissions`);
  }

  async gradeSubmission(submissionId: number, tutorId: number, grade: string, feedback?: string) {
    return this.request(`/admin/tutor/assignments/submissions/${submissionId}/grade`, {
      method: 'PUT',
      body: JSON.stringify({ tutorId, grade, feedback })
    });
  }

  async getQuizSubmissions(tutorId: number, quizId: number) {
    return this.request(`/admin/tutor/${tutorId}/quizzes/${quizId}/submissions`);
  }

  // Enrollment methods
  async getAllStudents() {
    return this.request('/admin/students');
  }

  async getCourseEnrollments(courseId: number) {
    return this.request(`/admin/courses/${courseId}/enrollments`);
  }

  async enrollStudents(studentIds: number[], courseId: number, assignedBy?: number) {
    return this.request('/admin/enrollments', {
      method: 'POST',
      body: JSON.stringify({ student_ids: studentIds, course_id: courseId, assigned_by: assignedBy })
    });
  }

  async unenrollStudent(courseId: number, studentId: number) {
    return this.request(`/admin/enrollments/${courseId}/${studentId}`, {
      method: 'DELETE'
    });
  }
}

export const apiService = new ApiService();
