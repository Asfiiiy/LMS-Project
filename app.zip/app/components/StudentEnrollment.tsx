'use client';

import { useState, useEffect } from 'react';
import { apiService } from '@/app/services/api';

interface Student {
  id: number;
  name: string;
  email: string;
}

interface EnrolledStudent {
  id: number;
  name: string;
  email: string;
  status: string;
  enrolled_at: string;
  assigned_by: number | null;
}

interface Course {
  id: number;
  title: string;
  description: string;
}

interface StudentEnrollmentProps {
  userId?: number; // For tracking who assigned the enrollment
  courses?: Course[]; // Optional: if not provided, will fetch all courses
}

const StudentEnrollment = ({ userId, courses: propCourses }: StudentEnrollmentProps) => {
  const [courses, setCourses] = useState<Course[]>(propCourses || []);
  const [allStudents, setAllStudents] = useState<Student[]>([]);
  const [enrolledStudents, setEnrolledStudents] = useState<EnrolledStudent[]>([]);
  const [selectedCourseId, setSelectedCourseId] = useState<number | ''>('');
  const [selectedStudentIds, setSelectedStudentIds] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);
  const [enrolling, setEnrolling] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [enrolledSearchTerm, setEnrolledSearchTerm] = useState('');

  useEffect(() => {
    fetchAllStudents();
    if (!propCourses || propCourses.length === 0) {
      fetchCourses();
    }
  }, []);

  useEffect(() => {
    if (selectedCourseId) {
      fetchEnrolledStudents(Number(selectedCourseId));
    } else {
      setEnrolledStudents([]);
    }
  }, [selectedCourseId]);

  const fetchCourses = async () => {
    try {
      const data = await apiService.getCourses();
      if (data.success) {
        setCourses(data.courses || []);
      }
    } catch (error) {
      console.error('Error fetching courses:', error);
    }
  };

  const fetchAllStudents = async () => {
    try {
      setLoading(true);
      const data = await apiService.getAllStudents();
      if (data.success) {
        setAllStudents(data.students || []);
      }
    } catch (error) {
      console.error('Error fetching students:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchEnrolledStudents = async (courseId: number) => {
    try {
      const data = await apiService.getCourseEnrollments(courseId);
      if (data.success) {
        setEnrolledStudents(data.students || []);
      }
    } catch (error) {
      console.error('Error fetching enrolled students:', error);
    }
  };

  const handleEnroll = async () => {
    if (!selectedCourseId || selectedStudentIds.length === 0) {
      alert('Please select a course and at least one student');
      return;
    }

    try {
      setEnrolling(true);
      const data = await apiService.enrollStudents(
        selectedStudentIds,
        Number(selectedCourseId),
        userId
      );

      if (data.success) {
        alert(data.message || 'Students enrolled successfully');
        setSelectedStudentIds([]);
        fetchEnrolledStudents(Number(selectedCourseId));
        // Refresh all students list in case of any updates
        fetchAllStudents();
      } else {
        alert(data.message || 'Error enrolling students');
      }
    } catch (error: any) {
      alert(error.message || 'Error enrolling students');
    } finally {
      setEnrolling(false);
    }
  };

  const handleUnenroll = async (studentId: number) => {
    if (!selectedCourseId) return;
    
    if (!confirm('Are you sure you want to unenroll this student from the course?')) {
      return;
    }

    try {
      const data = await apiService.unenrollStudent(Number(selectedCourseId), studentId);
      if (data.success) {
        alert('Student unenrolled successfully');
        fetchEnrolledStudents(Number(selectedCourseId));
      } else {
        alert(data.message || 'Error unenrolling student');
      }
    } catch (error: any) {
      alert(error.message || 'Error unenrolling student');
    }
  };

  const toggleStudentSelection = (studentId: number) => {
    setSelectedStudentIds(prev => {
      if (prev.includes(studentId)) {
        return prev.filter(id => id !== studentId);
      } else {
        return [...prev, studentId];
      }
    });
  };

  // Filter students based on search term and exclude already enrolled
  const availableStudents = allStudents.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.email.toLowerCase().includes(searchTerm.toLowerCase());
    const isNotEnrolled = !enrolledStudents.some(enrolled => enrolled.id === student.id);
    return matchesSearch && isNotEnrolled;
  });

  // Filter enrolled students based on search term
  const filteredEnrolledStudents = enrolledStudents.filter(student =>
    student.name.toLowerCase().includes(enrolledSearchTerm.toLowerCase()) ||
    student.email.toLowerCase().includes(enrolledSearchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Student Enrollment</h2>
        
        {/* Course Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Course
          </label>
          <select
            value={selectedCourseId}
            onChange={(e) => setSelectedCourseId(e.target.value ? Number(e.target.value) : '')}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#11CCEF] focus:border-transparent"
          >
            <option value="">-- Select a course --</option>
            {courses.map(course => (
              <option key={course.id} value={course.id}>
                {course.title}
              </option>
            ))}
          </select>
        </div>

        {selectedCourseId && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Enroll Students Section */}
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Enroll Students</h3>
              
              {/* Search */}
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="Search students..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#11CCEF] focus:border-transparent"
                />
              </div>

              {/* Student List */}
              <div className="max-h-96 overflow-y-auto border border-gray-200 rounded-lg mb-4">
                {loading ? (
                  <div className="p-4 text-center text-gray-500">Loading students...</div>
                ) : availableStudents.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">
                    {searchTerm ? 'No students found matching your search' : 'No students available to enroll'}
                  </div>
                ) : (
                  <div className="divide-y divide-gray-200">
                    {availableStudents.map(student => (
                      <label
                        key={student.id}
                        className="flex items-center p-3 hover:bg-gray-50 cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={selectedStudentIds.includes(student.id)}
                          onChange={() => toggleStudentSelection(student.id)}
                          className="w-4 h-4 text-[#11CCEF] border-gray-300 rounded focus:ring-[#11CCEF]"
                        />
                        <div className="ml-3 flex-1">
                          <div className="text-sm font-medium text-gray-900">{student.name}</div>
                          <div className="text-xs text-gray-500">{student.email}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* Enroll Button */}
              <button
                onClick={handleEnroll}
                disabled={selectedStudentIds.length === 0 || enrolling}
                className="w-full px-4 py-2 bg-[#11CCEF] text-white rounded-lg hover:bg-[#0daed9] transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                {enrolling ? 'Enrolling...' : `Enroll ${selectedStudentIds.length} Student(s)`}
              </button>
            </div>

            {/* Enrolled Students Section */}
            <div className="border border-gray-200 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Enrolled Students ({enrolledStudents.length})
              </h3>
              
              {/* Search */}
              <div className="mb-4">
                <input
                  type="text"
                  placeholder="Search enrolled students..."
                  value={enrolledSearchTerm}
                  onChange={(e) => setEnrolledSearchTerm(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#11CCEF] focus:border-transparent"
                />
              </div>

              {/* Enrolled Students List */}
              <div className="max-h-96 overflow-y-auto border border-gray-200 rounded-lg">
                {filteredEnrolledStudents.length === 0 ? (
                  <div className="p-4 text-center text-gray-500">
                    {enrolledSearchTerm ? 'No enrolled students found matching your search' : 'No students enrolled in this course yet'}
                  </div>
                ) : (
                  <div className="divide-y divide-gray-200">
                    {filteredEnrolledStudents.map(student => (
                      <div key={student.id} className="p-3 hover:bg-gray-50 flex items-center justify-between">
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-900">{student.name}</div>
                          <div className="text-xs text-gray-500">{student.email}</div>
                          <div className="text-xs text-gray-400 mt-1">
                            Status: {student.status} | Enrolled: {new Date(student.enrolled_at).toLocaleDateString()}
                          </div>
                        </div>
                        <button
                          onClick={() => handleUnenroll(student.id)}
                          className="ml-4 px-3 py-1 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200 transition-colors"
                        >
                          Unenroll
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {!selectedCourseId && (
          <div className="text-center py-12 text-gray-500">
            <div className="text-4xl mb-4">📚</div>
            <p>Please select a course to manage student enrollment</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentEnrollment;

