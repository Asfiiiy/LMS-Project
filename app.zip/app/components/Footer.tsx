import React from "react";
import Link from "next/link";
import styles from "./Footer.module.css";

const Footer = () => {
  return (
    <footer className="bg-[#2a2a2a] text-white">
      {/* Main Footer Sections */}
      <div className="container mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
        
        {/* Contact Section */}
        <div className="lg:col-span-1">
          <h3 className="font-bold mb-6 text-xl relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-12 after:h-1 after:bg-[#11CCEF]">
            Contact Us
          </h3>
          <div className="space-y-4">
            <div className="flex items-start">
              <svg className="w-5 h-5 text-[#11CCEF] mt-1 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
              </svg>
              <p className="text-gray-300 text-sm leading-relaxed">
                First Floor, Fairlawn High Street<br />Southall London UB1 3HB<br />United Kingdom
              </p>
            </div>
            
            <div className="flex items-center">
              <svg className="w-5 h-5 text-[#11CCEF] mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
              </svg>
              <div className="text-gray-300 text-sm">
                <p>+44 (0) 20 7101 9543</p>
                <p>+44 (0) 20 3983 2988</p>
                <p>+44 (0) 78 4684 7013</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <svg className="w-5 h-5 text-[#11CCEF] mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
              </svg>
              <p className="text-gray-300 text-sm">info@inspirelondoncollege.co.uk</p>
            </div>
          </div>

          {/* Social Icons */}
          <div className="mt-6">
            <h4 className="font-semibold mb-4 text-gray-300">Follow Us</h4>
            <div className="flex space-x-3">
              {[
                { name: "Facebook", icon: "M20 1.892a8.178 8.178 0 0 1-2.355.635 4.074 4.074 0 0 0 1.8-2.235 8.344 8.344 0 0 1-2.605.98A4.13 4.13 0 0 0 13.85 0 4.068 4.068 0 0 0 9.8 4.034a4.13 4.13 0 0 0 .105.94A11.705 11.705 0 0 1 1.392.738 4.06 4.06 0 0 0 .84 2.87c0 .718.27 1.375.72 1.887a4.108 4.108 0 0 1-1.86-.513v.052a4.1 4.1 0 0 0 3.292 4.022 4.095 4.095 0 0 1-1.075.135c-.263 0-.52-.025-.77-.075a4.112 4.112 0 0 0 3.833 2.85A8.261 8.261 0 0 1 0 14.185 11.732 11.732 0 0 0 6.29 16c7.547 0 11.675-6.244 11.675-11.654 0-.18-.005-.362-.013-.54A8.36 8.36 0 0 0 20 1.892z" },
                // { name: "Twitter", icon: "M6.29 18.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0020 3.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.073 4.073 0 01.8 7.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 010 16.407a11.616 11.616 0 006.29 1.84" },
                { name: "Youtube", icon: "M2 3a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H2zm0 2h16v10H2V5zm5 2v6l6-3-6-3z" },
                // { name: "Instagram", icon: "M10 0a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm3.5 5h-7c-.8 0-1.5.7-1.5 1.5v7c0 .8.7 1.5 1.5 1.5h7c.8 0 1.5-.7 1.5-1.5v-7c0-.8-.7-1.5-1.5-1.5zm-3.5 8a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm3-5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z" },
                { name: "Linkedin", icon: "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6zM2 9h4v12H2zM4 6a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" },
                { name: "Pinterest", icon: "M10 0a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15a5 5 0 0 1-5-5c0-2.5 1.5-5 5-5 3 0 5 2 5 5 0 3-2 5-5 5zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6z" }
              ].map((social) => (
                <Link 
                  key={social.name} 
                  href="#" 
                  className={`${styles.socialLink} bg-[#3a3a3a] hover:bg-[#11CCEF] p-2 rounded-lg transition-all duration-300 group`}
                  aria-label={social.name}
                >
                  <svg className="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d={social.icon} clipRule="evenodd" />
                  </svg>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Company Links */}
        <div>
          <h3 className="font-bold mb-6 text-xl relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-12 after:h-1 after:bg-[#11CCEF]">
            Company
          </h3>
          <ul className="space-y-3">
            {["About", "Contact Us", "Blog", "FAQs", "How to Pay", "Request Info", "Fee & Pricing", "Jobs"].map((item) => (
              <li key={item}>
                <Link href="#" className={`${styles.footerLink} text-gray-300 hover:text-white flex items-center group text-sm transition-all duration-300`}>
                  <svg className="w-3 h-3 mr-2 text-[#11CCEF] opacity-0 group-hover:opacity-100 transition-opacity duration-300" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                  </svg>
                  {item}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Popular Categories */}
        <div>
          <h3 className="font-bold mb-6 text-xl relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-12 after:h-1 after:bg-[#11CCEF]">
            Popular Categories
          </h3>
          <ul className="space-y-3">
            {["Accounting and Finance", "Business Management", "Education & Training", "Health & Social care", "Project Management", "IT & Computer Science", "Marketing", "Hospitality"].map((item) => (
              <li key={item}>
                <Link href="#" className={`${styles.footerLink} text-gray-300 hover:text-white text-sm leading-relaxed transition-all duration-300 block py-1`}>
                  {item}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Popular Courses */}
        <div>
          <h3 className="font-bold mb-6 text-xl relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-12 after:h-1 after:bg-[#11CCEF]">
            Popular Courses
          </h3>
          <ul className="space-y-3">
            {[
              "Level 3 Certificate in Phlebotomy",
              "Level 3 Health & Social Care", 
              "Regulated Qualifications",
              "Diploma in Business Administration",
              "Cyber Security Fundamentals",
              "Digital Marketing Professional"
            ].map((item) => (
              <li key={item}>
                <Link href="#" className={`${styles.footerLink} text-gray-300 hover:text-white text-sm leading-relaxed transition-all duration-300 block py-1`}>
                  {item}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Quick Links Bar */}
      <div className="bg-gradient-to-r from-[#11CCEF] to-[#0ea5e9] text-[#1a1a1a] py-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row justify-between items-center space-y-3 lg:space-y-0">
            <div className="flex flex-wrap justify-center gap-3 lg:gap-4 text-sm font-medium">
              {["All Short Courses", "Regulated Qualifications", "Certificate", "Apply For Certificate", "Student Discount", "Care Certificate", "Give Reviews"].map((item) => (
                <Link 
                  key={item} 
                  href="#" 
                className={`${styles.footerLink} bg-white/20 hover:bg-white hover:text-black italic px-3 py-1 rounded-full transition-all duration-300 text-sm backdrop-blur-sm`} >
                  {item}
                </Link>
              ))}
            </div>
            <div className="flex flex-wrap justify-center gap-4 text-sm font-medium">
              {["Privacy Policy", "Terms & Conditions", "Cookie Policy"].map((item) => (
                <Link 
                  key={item} 
                  href="#" 
                  className={`${styles.footerLink} hover:text-white italic transition-colors duration-300 text-sm`}
                >
                  {item}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="bg-[#1a1a1a] text-center py-4">
        <div className="container mx-auto px-4">
          <p className="text-gray-400 text-sm">
            © Copyright 2013 – 2025 – Inspire London College – All Rights Reserved 
            <span className="hidden sm:inline"> | </span>
            <br className="sm:hidden" />
            Powered by <span className="text-[#11CCEF] font-medium">Whoopit Agency</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;