'use client';

import { useState, useEffect } from 'react';
import { apiService } from '@/app/services/api';

interface Course {
  id: number;
  title: string;
  description: string;
  status: string;
  created_by: number;
  created_by_name: string;
  category_id: number;
  category_name: string;
  created_at: string;
}

interface Category {
  id: number;
  name: string;
  description: string;
}

interface SubCategory {
  id: number;
  category_id: number;
  name: string;
  description: string;
}

interface CourseFile {
  id: number;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  created_at: string;
}

interface CourseManagementProps {
  role?: 'Admin' | 'Tutor' | 'Manager' | 'Student' | 'Moderator';
  userId?: number;
  showCategoryManagement?: boolean;
  showBackupRestore?: boolean;
}

const CourseManagement = ({ 
  role = 'Admin', 
  userId, 
  showCategoryManagement = true,
  showBackupRestore = true 
}: CourseManagementProps = {}) => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [subCategories, setSubCategories] = useState<SubCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [courseFiles, setCourseFiles] = useState<CourseFile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'Active',
    created_by: '',
    category_id: '',
    sub_category_id: '',
    start_date: '',
    end_date: ''
  });

  const [categoryFormData, setCategoryFormData] = useState({
    name: '',
    description: ''
  });

  const [showSubCategoryForm, setShowSubCategoryForm] = useState(false);
  const [subCategoryFormData, setSubCategoryFormData] = useState({
    category_id: '',
    name: '',
    description: ''
  });

  useEffect(() => {
    fetchData();
  }, [role, userId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Fetch courses - tutors use same endpoint as admin (they can see all courses)
      let coursesData;
      if (role === 'Tutor' && userId) {
        coursesData = await apiService.getTutorCourses(userId);
      } else {
        coursesData = await apiService.getCourses();
      }

      // Only fetch categories if category management is enabled (Admin only)
      const categoriesData = showCategoryManagement 
        ? await apiService.getCourseCategories()
        : { success: true, categories: [] };

      if (coursesData.success) {
        setCourses(coursesData.courses);
      }
      if (categoriesData.success) {
        setCategories(categoriesData.categories);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to connect to API. Please restart the backend server.');
    } finally {
      setLoading(false);
    }
  };

  const fetchSubCategories = async (categoryId: number) => {
    if (!categoryId) {
      setSubCategories([]);
      return;
    }
    try {
      const data = await apiService.getSubCategories(categoryId);
      if (data.success) {
        setSubCategories(data.subCategories);
      }
    } catch (error) {
      console.error('Error fetching sub-categories:', error);
    }
  };

  const handleCreateCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const user = JSON.parse(localStorage.getItem('lms-user') || '{}');
      // Use userId prop if provided (for tutors), otherwise use user from localStorage
      const createdBy = userId || user.id;
      const courseData = {
        ...formData,
        created_by: createdBy
      };
      
      const data = await apiService.createCourse(courseData);
      if (data.success) {
        fetchData();
        setShowCreateForm(false);
        setFormData({ title: '', description: '', status: 'Active', created_by: '', category_id: '', sub_category_id: '', start_date: '', end_date: '' });
        setSubCategories([]);
        alert('Course created successfully!');
      } else {
        alert(data.message || 'Error creating course');
      }
    } catch (error) {
      console.error('Error creating course:', error);
      alert('Error creating course');
    }
  };

  const handleUpdateCourse = async (e: React.FormEvent) => {
    try {
      const data = await apiService.updateCourse(editingCourse!.id, formData);
      if (data.success) {
        fetchData();
        setEditingCourse(null);
        setFormData({ title: '', description: '', status: 'Active', created_by: '', category_id: '', sub_category_id: '', start_date: '', end_date: '' });
        setSubCategories([]);
        alert('Course updated successfully!');
      } else {
        alert(data.message || 'Error updating course');
      }
    } catch (error) {
      console.error('Error updating course:', error);
      alert('Error updating course');
    }
  };

  const handleDeleteCourse = async (courseId: number) => {
    if (!confirm('Are you sure you want to delete this course?')) return;
    
    try {
      const data = await apiService.deleteCourse(courseId);
      if (data.success) {
        fetchData();
        alert('Course deleted successfully!');
      } else {
        alert(data.message || 'Error deleting course');
      }
    } catch (error) {
      console.error('Error deleting course:', error);
      alert('Error deleting course');
    }
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = await apiService.createCourseCategory(categoryFormData);
      if (data.success) {
        fetchData();
        setShowCategoryForm(false);
        setCategoryFormData({ name: '', description: '' });
        alert('Category created successfully!');
      } else {
        alert(data.message || 'Error creating category');
      }
    } catch (error) {
      console.error('Error creating category:', error);
      alert('Error creating category');
    }
  };

  const handleCreateSubCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subCategoryFormData.category_id) {
      alert('Please select a category first');
      return;
    }
    try {
      const data = await apiService.createSubCategory(subCategoryFormData);
      if (data.success) {
        fetchData();
        setShowSubCategoryForm(false);
        setSubCategoryFormData({ category_id: '', name: '', description: '' });
        alert('Sub-category created successfully!');
      } else {
        alert(data.message || 'Error creating sub-category');
      }
    } catch (error) {
      console.error('Error creating sub-category:', error);
      alert('Error creating sub-category');
    }
  };

  const handleFileUpload = async (courseId: number, file: File, fileType: string) => {
    try {
      const data = await apiService.uploadCourseFile(courseId, file, fileType);
      if (data.success) {
        fetchCourseFiles(courseId);
        alert('File uploaded successfully!');
      } else {
        alert(data.message || 'Error uploading file');
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Error uploading file');
    }
  };

  const fetchCourseFiles = async (courseId: number) => {
    try {
      const data = await apiService.getCourseFiles(courseId);
      if (data.success) {
        setCourseFiles(data.files);
      }
    } catch (error) {
      console.error('Error fetching course files:', error);
    }
  };

  const handleBackupCourses = async () => {
    try {
      const data = await apiService.backupCourses();
      if (data.success) {
        alert(`Backup created successfully! ${data.coursesCount} courses backed up.`);
      } else {
        alert(data.message || 'Error creating backup');
      }
    } catch (error) {
      console.error('Error creating backup:', error);
      alert('Error creating backup');
    }
  };

  const handleRestoreCourses = async (file: File) => {
    try {
      const data = await apiService.restoreCourses(file);
      if (data.success) {
        fetchData();
        alert(`Courses restored successfully! ${data.restoredCourses} courses restored.`);
      } else {
        alert(data.message || 'Error restoring courses');
      }
    } catch (error) {
      console.error('Error restoring courses:', error);
      alert('Error restoring courses');
    }
  };

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !filterCategory || course.category_name === filterCategory;
    const matchesStatus = !filterStatus || course.status === filterStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800';
      case 'Inactive': return 'bg-red-100 text-red-800';
      case 'Draft': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Loading courses...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <div className="flex items-center">
          <div className="text-red-600 text-lg mr-3">⚠️</div>
          <div>
            <h3 className="text-red-800 font-semibold">Connection Error</h3>
            <p className="text-red-600 mt-1">{error}</p>
            <button 
              onClick={fetchData}
              className="mt-3 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              Retry Connection
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold">
          {role === 'Tutor' ? 'My Courses' : 'Course Management'}
        </h2>
        <div className="flex space-x-3">
          {showCategoryManagement && (
            <>
              <button
                onClick={() => setShowCategoryForm(true)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                + Add Category
              </button>
              <button
                onClick={() => setShowSubCategoryForm(true)}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                + Add Sub-Category
              </button>
            </>
          )}
          <button
            onClick={() => setShowCreateForm(true)}
            className="px-4 py-2 bg-[#11CCEF] text-white rounded-lg hover:bg-[#0daed9] transition-colors"
          >
            + Add Course
          </button>
        </div>
      </div>

      {/* Backup/Restore Section - Admin only */}
      {showBackupRestore && (
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold mb-3">Backup & Restore</h3>
          <div className="flex space-x-4">
            <button
              onClick={handleBackupCourses}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              📦 Backup All Courses
            </button>
            <label className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors cursor-pointer">
              📥 Restore Courses (.mbz/.json)
              <input
                type="file"
                accept=".mbz,.json"
                onChange={(e) => {
                  if (e.target.files?.[0]) {
                    handleRestoreCourses(e.target.files[0]);
                  }
                }}
                className="hidden"
              />
            </label>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Search Courses</label>
            <input
              type="text"
              placeholder="Search by title or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Category</label>
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
            >
              <option value="">All Categories</option>
              {categories.map(category => (
                <option key={category.id} value={category.name}>{category.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Status</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
            >
              <option value="">All Status</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Draft">Draft</option>
            </select>
          </div>
        </div>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map((course) => (
          <div key={course.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-6">
              <div className="flex justify-between items-start mb-3">
                <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">{course.title}</h3>
                <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(course.status)}`}>
                  {course.status}
                </span>
              </div>
              
              <p className="text-gray-600 text-sm mb-3 line-clamp-3">{course.description}</p>
              
              <div className="space-y-2 text-sm text-gray-500">
                <div>📚 Category: {course.category_name || 'No Category'}</div>
                {role === 'Tutor' && (course as any).student_count !== undefined && (
                  <>
                    <div>👥 Students: {(course as any).student_count || 0}</div>
                    <div>📝 Assignments: {(course as any).assignment_count || 0}</div>
                    <div>❓ Quizzes: {(course as any).quiz_count || 0}</div>
                  </>
                )}
                {role !== 'Tutor' && (
                  <>
                    <div>👤 Created by: {course.created_by_name}</div>
                    <div>📅 Created: {new Date(course.created_at).toLocaleDateString()}</div>
                  </>
                )}
              </div>
            </div>
            
            <div className="px-6 py-3 bg-gray-50 border-t border-gray-200">
              <div className="flex justify-between items-center">
                <a
                  href={`/courses/${course.id}/files`}
                  target="_blank"
                  className="text-[#11CCEF] hover:text-[#0daed9] text-sm font-medium"
                >
                  📁 Files
                </a>
                <div className="flex space-x-2">
                  <button
                    onClick={() => {
                      window.location.href = `/courses/${course.id}`;
                    }}
                    className="text-green-600 hover:text-green-800 text-sm"
                  >
                    View
                  </button>
                  <button
                    onClick={() => {
                      setEditingCourse(course);
                      setFormData({
                        title: course.title,
                        description: course.description,
                        status: course.status,
                        created_by: course.created_by.toString(),
                        category_id: course.category_id?.toString() || '',
                        sub_category_id: (course as any).sub_category_id?.toString() || '',
                        start_date: (course as any).start_date ? (course as any).start_date.split('T')[0] : '',
                        end_date: (course as any).end_date ? (course as any).end_date.split('T')[0] : ''
                      });
                      if (course.category_id) {
                        fetchSubCategories(course.category_id);
                      }
                    }}
                    className="text-blue-600 hover:text-blue-800 text-sm"
                  >
                    Edit
                  </button>
                  {role === 'Admin' && (
                    <button
                      onClick={() => handleDeleteCourse(course.id)}
                      className="text-red-600 hover:text-red-800 text-sm"
                    >
                      Delete
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Course Files Modal */}
      {selectedCourse && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Course Files: {selectedCourse.title}</h3>
              <button
                onClick={() => setSelectedCourse(null)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕
              </button>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Upload New File</label>
              <input
                type="file"
                onChange={(e) => {
                  if (e.target.files?.[0]) {
                    const file = e.target.files[0];
                    const fileType = file.name.endsWith('.mbz') ? 'moodle' : 'resource';
                    handleFileUpload(selectedCourse.id, file, fileType);
                  }
                }}
                accept=".mbz,.zip,.pdf,.mp4,.doc,.docx,.ppt,.pptx"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
              />
            </div>
            
            <div className="space-y-2">
              {courseFiles.map((file) => (
                <div key={file.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium">{file.file_name}</div>
                    <div className="text-sm text-gray-500">
                      {file.file_type} • {formatFileSize(file.file_size)} • {new Date(file.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button className="text-blue-600 hover:text-blue-800">Download</button>
                    <button className="text-red-600 hover:text-red-800">Delete</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Create/Edit Course Modal */}
      {(showCreateForm || editingCourse) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">
              {editingCourse ? 'Edit Course' : 'Create New Course'}
            </h3>
            <form onSubmit={editingCourse ? handleUpdateCourse : handleCreateCourse} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  required
                  rows={3}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select
                  required
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                  <option value="Draft">Draft</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                  value={formData.category_id}
                  onChange={(e) => {
                    setFormData({ ...formData, category_id: e.target.value, sub_category_id: '' });
                    fetchSubCategories(Number(e.target.value));
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                >
                  <option value="">No Category</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.id}>{category.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Sub-Category</label>
                <select
                  value={formData.sub_category_id}
                  onChange={(e) => setFormData({ ...formData, sub_category_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                  disabled={!formData.category_id}
                >
                  <option value="">No Sub-Category</option>
                  {subCategories.map(subCat => (
                    <option key={subCat.id} value={subCat.id}>{subCat.name}</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                  <input
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                  />
                </div>
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateForm(false);
                    setEditingCourse(null);
                    setFormData({ title: '', description: '', status: 'Active', created_by: '', category_id: '', sub_category_id: '', start_date: '', end_date: '' });
                    setSubCategories([]);
                  }}
                  className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#11CCEF] text-white rounded-lg hover:bg-[#0daed9]"
                >
                  {editingCourse ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Category Modal */}
      {showCategoryForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Create New Category</h3>
            <form onSubmit={handleCreateCategory} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category Name</label>
                <input
                  type="text"
                  required
                  value={categoryFormData.name}
                  onChange={(e) => setCategoryFormData({ ...categoryFormData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={categoryFormData.description}
                  onChange={(e) => setCategoryFormData({ ...categoryFormData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#11CCEF]"
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowCategoryForm(false);
                    setCategoryFormData({ name: '', description: '' });
                  }}
                  className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Create Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Sub-Category Modal */}
      {showSubCategoryForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Create New Sub-Category</h3>
            <form onSubmit={handleCreateSubCategory} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Parent Category <span className="text-red-500">*</span>
                </label>
                <select
                  required
                  value={subCategoryFormData.category_id}
                  onChange={(e) => setSubCategoryFormData({ ...subCategoryFormData, category_id: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600"
                >
                  <option value="">Select a category</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.id}>{category.name}</option>
                  ))}
                </select>
                {categories.length === 0 && (
                  <p className="text-sm text-gray-500 mt-1">No categories available. Please create a category first.</p>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Sub-Category Name</label>
                <input
                  type="text"
                  required
                  value={subCategoryFormData.name}
                  onChange={(e) => setSubCategoryFormData({ ...subCategoryFormData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Enter sub-category name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={subCategoryFormData.description}
                  onChange={(e) => setSubCategoryFormData({ ...subCategoryFormData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600"
                  placeholder="Enter sub-category description (optional)"
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowSubCategoryForm(false);
                    setSubCategoryFormData({ category_id: '', name: '', description: '' });
                  }}
                  className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!subCategoryFormData.category_id || categories.length === 0}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Create Sub-Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CourseManagement;
