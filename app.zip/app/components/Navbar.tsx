'use client';

import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';

interface User {
  name: string;
  role: 'Admin' | 'Tutor' | 'Manager' | 'Student' | 'Moderator' | null;
}

const Navbar = () => {
  const [user, setUser] = useState<User | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const router = useRouter();
  const isUpdatingRef = useRef(false);

  // Optimized function to check and update user state with immediate sync
  const checkUserState = useCallback(() => {
    // Prevent multiple simultaneous updates
    if (isUpdatingRef.current) return;
    isUpdatingRef.current = true;

    try {
      const userData = localStorage.getItem('lms-user');
      if (userData) {
        const parsedUser = JSON.parse(userData);
        // Use requestAnimationFrame for immediate visual update
        requestAnimationFrame(() => {
          setUser(parsedUser);
          isUpdatingRef.current = false;
        });
      } else {
        requestAnimationFrame(() => {
          setUser(null);
          isUpdatingRef.current = false;
        });
      }
    } catch (error) {
      console.error('Error parsing user data:', error);
      requestAnimationFrame(() => {
        setUser(null);
        isUpdatingRef.current = false;
      });
    }
  }, []);

  // Initial user check and setup listeners for instant updates
  useEffect(() => {
    // Initial check - synchronous for first render
    try {
      const userData = localStorage.getItem('lms-user');
      if (userData) {
        const parsedUser = JSON.parse(userData);
        setUser(parsedUser);
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error('Error parsing user data:', error);
      setUser(null);
    }

    // Listen for storage events (works across tabs/windows)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'lms-user' || e.key === 'lms-token') {
        checkUserState();
      }
    };

    // Listen for custom auth events (works in same tab) - immediate update
    const handleAuthChange = () => {
      // Immediate synchronous check for instant UI update
      try {
        const userData = localStorage.getItem('lms-user');
        if (userData) {
          const parsedUser = JSON.parse(userData);
          setUser(parsedUser);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Error parsing user data:', error);
        setUser(null);
      }
    };

    // Add event listeners with immediate flag for better performance
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('auth-change', handleAuthChange, false);
    window.addEventListener('login', handleAuthChange, false);
    window.addEventListener('logout', handleAuthChange, false);

    // Update on page visibility change (when user returns to tab)
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        checkUserState();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Cleanup
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('auth-change', handleAuthChange);
      window.removeEventListener('login', handleAuthChange);
      window.removeEventListener('logout', handleAuthChange);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [checkUserState]);

  // Optimized scroll effect for navbar with throttling
  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setScrolled(window.scrollY > 10);
          ticking = false;
        });
        ticking = true;
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Memoized logout handler
  const handleLogout = useCallback(() => {
    router.push('/logout');
  }, [router]);

  // Memoized user display name initial
  const userInitial = useMemo(() => {
    return user?.name?.charAt(0).toUpperCase() || '';
  }, [user?.name]);

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-300 ${
      scrolled 
        ? 'bg-white/95 backdrop-blur-xl shadow-2xl border-b border-gray-100' 
        : 'bg-white shadow-md'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          {/* Logo */}
          <Link href="/" className="flex items-center group">
            <div className="relative group-hover:scale-110 transition-transform duration-300">
              <Image 
                src="/assets/logo.png" 
                alt="LMS Logo" 
                width={40} 
                height={40}
                className="object-contain"
              />
            </div>
          </Link>

          {/* Animated "Inspire LMS" in the middle */}
          <div className="flex-1 flex justify-center">
            <h1 className="text-3xl font-black bg-gradient-to-r from-[#11CCEF] to-[#E51791] bg-clip-text text-transparent animate-pulse">
              Inspire LMS
            </h1>
          </div>

          {/* Right Menu */}
          <div className="flex items-center space-x-3">
            {!user ? (
              <>
                <Link
                  href="/login"
                  className="px-6 py-3 bg-gradient-to-r from-[#11CCEF] to-[#12B7F3] text-white rounded-2xl font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                >
                  Login
                </Link>
                <Link
                  href="/register"
                  className="px-6 py-3 border-2 border-[#11CCEF] text-[#11CCEF] rounded-2xl font-semibold hover:bg-[#11CCEF] hover:text-white transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  Register
                </Link>
              </>
            ) : (
              <>
                {/* Role-based Links */}
                {user.role === 'Admin' && (
                  <Link
                    href="/dashboard/admin"
                    className="px-6 py-3 bg-gradient-to-r from-[#E51791] to-[#c4127a] text-white rounded-2xl font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                  >
                    Admin Dashboard
                  </Link>
                )}
                {user.role === 'Tutor' && (
                  <Link
                    href="/dashboard/tutor"
                    className="px-6 py-3 bg-gradient-to-r from-[#E51791] to-[#c4127a] text-white rounded-2xl font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                  >
                    Tutor Dashboard
                  </Link>
                )}
                {['Manager', 'Student', 'Moderator'].includes(user.role!) && (
                  <Link
                    href="/dashboard"
                    className="px-6 py-3 bg-gradient-to-r from-[#E51791] to-[#c4127a] text-white rounded-2xl font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
                  >
                    Dashboard
                  </Link>
                )}

                {/* Profile / Logout */}
                <div className="relative">
                  <button
                    onClick={() => setMenuOpen(!menuOpen)}
                    className="flex items-center gap-3 px-4 py-3 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-all duration-300 border border-gray-200 shadow-lg hover:shadow-xl group"
                  >
                    <div className="w-8 h-8 bg-gradient-to-r from-[#11CCEF] to-[#E51791] rounded-full flex items-center justify-center text-white font-semibold text-sm">
                      {userInitial}
                    </div>
                    <span className="font-semibold text-gray-800">{user.name}</span>
                    <svg 
                      className={`w-4 h-4 text-gray-500 transition-transform duration-300 ${menuOpen ? 'rotate-180' : ''}`}
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  
                  {menuOpen && (
                    <div className="absolute right-0 mt-3 w-56 bg-white/95 backdrop-blur-xl rounded-2xl border border-gray-200 shadow-2xl py-3 z-50 animate-in fade-in slide-in-from-top-5 duration-300">
                      <div className="px-4 py-3 border-b border-gray-100">
                        <div className="font-semibold text-gray-800">{user.name}</div>
                        <div className="text-sm text-gray-500 capitalize">{user.role?.toLowerCase()}</div>
                      </div>
                      
                      <Link
                        href="/profile"
                        className="block px-4 py-3 text-gray-700 hover:bg-gray-50 transition-colors duration-200 font-medium"
                        onClick={() => setMenuOpen(false)}
                      >
                        Profile Settings
                      </Link>
                      
                      <button
                        onClick={() => {
                          handleLogout();
                          setMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-3 text-red-500 hover:bg-red-50 transition-colors duration-200 font-semibold border-t border-gray-100"
                      >
                        Logout
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;