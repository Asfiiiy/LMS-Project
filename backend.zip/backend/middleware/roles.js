// backend/middleware/permit.js
const permit = (...allowedRoles) => {
  return (req, res, next) => {
    const userRoleId = req.user?.role_id;

    // If allowedRoles contains role IDs, check directly
    if (allowedRoles.includes(userRoleId)) {
      return next();
    }

    // Optionally, if allowedRoles contains role names, map them to IDs here
    // const roleMap = { Admin: 1, Tutor: 2, Manager: 3, Student: 4, Moderator: 5 };
    // const allowedRoleIds = allowedRoles.map(role => roleMap[role]);
    // if (allowedRoleIds.includes(userRoleId)) return next();

    return res.status(403).json({ message: 'Forbidden: Insufficient permissions' });
  };
};

module.exports = { permit };
