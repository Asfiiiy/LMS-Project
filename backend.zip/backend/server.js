const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
// Serve uploaded files (legacy only - new files are stored in Cloudinary, not locally)
// This is kept for backward compatibility with any old files
app.use('/uploads', express.static('uploads'));

// Routes
app.use('/api/login', require('./routes/auth')); // Auth route (login)
app.use('/api/users', require('./routes/users')); // Users CRUD
app.use('/api/courses', require('./routes/courses')); // Courses CRUD
app.use('/api/admin', require('./routes/admin')); // Admin management

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
