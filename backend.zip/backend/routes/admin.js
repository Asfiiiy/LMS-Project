const express = require('express');
const pool = require('../config/db');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const AdmZip = require('adm-zip');
const cloudinary = require('../config/cloudinary');
const https = require('https');
const http = require('http');
const router = express.Router();

// Configure multer for file uploads (memory storage for Cloudinary)
const storage = multer.memoryStorage();

const upload = multer({ 
  storage: storage, // Memory storage only - files go directly to Cloudinary
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit (Cloudinary free tier allows up to 10MB, but we'll handle larger files)
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.mbz', '.json', '.zip', '.pdf', '.mp4', '.doc', '.docx', '.ppt', '.pptx', '.jpg', '.jpeg', '.png', '.gif'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type.'));
    }
  }
});

// Helper function to upload to Cloudinary
// NOTE: All files are uploaded to Cloudinary only. No local storage.
async function uploadToCloudinary(file, folder = 'lms') {
  return new Promise((resolve, reject) => {
    // Determine resource type based on file extension
    const ext = path.extname(file.originalname).toLowerCase();
    let resourceType = 'auto';
    
    // For videos, use 'video' type for better streaming support
    const videoTypes = ['.mp4', '.mov', '.avi', '.wmv', '.flv', '.webm'];
    if (videoTypes.includes(ext)) {
      resourceType = 'video';
    }
    // For PDFs and documents, use 'raw' to ensure proper access
    else {
      const rawTypes = ['.pdf', '.doc', '.docx', '.ppt', '.pptx', '.xls', '.xlsx', '.txt', '.zip', '.rar', '.mbz'];
      if (rawTypes.includes(ext)) {
        resourceType = 'raw';
      }
    }
    
    // Check file size - Cloudinary free tier has 10MB limit for raw files
    const fileSizeMB = file.buffer.length / (1024 * 1024);
    if (resourceType === 'raw' && fileSizeMB > 10) {
      return reject(new Error(`File size (${fileSizeMB.toFixed(2)}MB) exceeds Cloudinary free tier limit of 10MB for raw files. Please use a smaller file or upgrade your Cloudinary plan.`));
    }
    
    // Videos can be larger, but warn if very large
    if (resourceType === 'video' && fileSizeMB > 100) {
      console.warn(`Large video file detected: ${fileSizeMB.toFixed(2)}MB. Upload may take longer.`);
    }
    
    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder: folder,
        resource_type: resourceType,
        // Ensure files are publicly accessible
        access_mode: 'public',
        // For videos, enable eager transformations for better streaming
        ...(resourceType === 'video' && {
          eager: [{ format: 'mp4' }],
          eager_async: false,
        }),
        // For large files, use chunked upload
        chunk_size: 6000000, // 6MB chunks
      },
      (error, result) => {
        if (error) {
          console.error('Cloudinary upload error:', error);
          reject(error);
        } else {
          resolve(result);
        }
      }
    );
    uploadStream.end(file.buffer);
  });
}

// Test route to verify admin API is working
router.get('/test', (req, res) => {
  res.json({ success: true, message: 'Admin API is working!' });
});

// ===============================
// USER MANAGEMENT
// ===============================

// Get all roles
router.get('/roles', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM roles ORDER BY id');
    res.json({ success: true, roles: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching roles' });
  }
});

// Get all users with roles
router.get('/users', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT u.*, r.name as role_name 
      FROM users u 
      LEFT JOIN roles r ON u.role_id = r.id 
      ORDER BY u.created_at DESC
    `);
    res.json({ success: true, users: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching users' });
  }
});

// Create new user
router.post('/users', async (req, res) => {
  try {
    const { name, email, password, role_id, manager_id } = req.body;
    
    if (!name || !email || !password || !role_id) {
      return res.status(400).json({ success: false, message: 'All fields are required' });
    }

    // Check if user already exists
    const [existing] = await pool.execute('SELECT id FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(400).json({ success: false, message: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert user
    const [result] = await pool.execute(
      'INSERT INTO users (name, email, password_hash, role_id, manager_id) VALUES (?, ?, ?, ?, ?)',
      [name, email, hashedPassword, role_id, manager_id || null]
    );

    res.json({ success: true, message: 'User created successfully', userId: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating user' });
  }
});

// Update user
router.put('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, role_id, manager_id } = req.body;

    await pool.execute(
      'UPDATE users SET name = ?, email = ?, role_id = ?, manager_id = ? WHERE id = ?',
      [name, email, role_id, manager_id || null, id]
    );

    res.json({ success: true, message: 'User updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error updating user' });
  }
});

// Delete user
router.delete('/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute('DELETE FROM users WHERE id = ?', [id]);
    res.json({ success: true, message: 'User deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error deleting user' });
  }
});

// ===============================
// COURSE MANAGEMENT
// ===============================

// Get all course categories
router.get('/course-categories', async (req, res) => {
  try {
    const [rows] = await pool.execute('SELECT * FROM course_categories ORDER BY name');
    res.json({ success: true, categories: rows });
  } catch (err) {
    console.error(err);
    // If table doesn't exist, return empty array
    if (err.code === 'ER_NO_SUCH_TABLE') {
      res.json({ success: true, categories: [] });
    } else {
      res.status(500).json({ success: false, message: 'Error fetching categories' });
    }
  }
});

// Get sub-categories by category
router.get('/sub-categories/:categoryId', async (req, res) => {
  try {
    const { categoryId } = req.params;
    const [rows] = await pool.execute('SELECT * FROM sub_categories WHERE category_id = ? ORDER BY name', [categoryId]);
    res.json({ success: true, subCategories: rows });
  } catch (err) {
    console.error(err);
    if (err.code === 'ER_NO_SUCH_TABLE') {
      res.json({ success: true, subCategories: [] });
    } else {
      res.status(500).json({ success: false, message: 'Error fetching sub-categories' });
    }
  }
});

// Create sub-category
router.post('/sub-categories', async (req, res) => {
  try {
    const { category_id, name, description } = req.body;
    const [result] = await pool.execute(
      'INSERT INTO sub_categories (category_id, name, description) VALUES (?, ?, ?)',
      [category_id, name, description || '']
    );
    res.json({ success: true, message: 'Sub-category created successfully', subCategoryId: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating sub-category' });
  }
});

// Create course category
router.post('/course-categories', async (req, res) => {
  try {
    const { name, description } = req.body;
    const [result] = await pool.execute(
      'INSERT INTO course_categories (name, description) VALUES (?, ?)',
      [name, description]
    );
    res.json({ success: true, message: 'Category created successfully', categoryId: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating category' });
  }
});

// Get all courses with categories
router.get('/courses', async (req, res) => {
  try {
    // Try to get courses with categories and sub-categories first
    try {
      const [rows] = await pool.execute(`
        SELECT c.*, u.name as created_by_name, cat.name as category_name, subcat.name as sub_category_name
        FROM courses c 
        LEFT JOIN users u ON c.created_by = u.id 
        LEFT JOIN course_categories cat ON c.category_id = cat.id
        LEFT JOIN sub_categories subcat ON c.sub_category_id = subcat.id
        ORDER BY c.created_at DESC
      `);
      res.json({ success: true, courses: rows });
    } catch (tableErr) {
      // If course_categories table doesn't exist, use simpler query
      if (tableErr.code === 'ER_NO_SUCH_TABLE') {
        const [rows] = await pool.execute(`
          SELECT c.*, u.name as created_by_name, NULL as category_name, NULL as sub_category_name
          FROM courses c 
          LEFT JOIN users u ON c.created_by = u.id 
          ORDER BY c.created_at DESC
        `);
        res.json({ success: true, courses: rows });
      } else {
        throw tableErr;
      }
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching courses' });
  }
});

// Get single course details (course, files, assignments, quizzes)
router.get('/courses/:id/detail', async (req, res) => {
  try {
    const { id } = req.params;

    // Course with optional category and sub-category
    let courseRows;
    try {
      [courseRows] = await pool.execute(`
        SELECT c.*, u.name as created_by_name, cat.name as category_name, subcat.name as sub_category_name
        FROM courses c 
        LEFT JOIN users u ON c.created_by = u.id 
        LEFT JOIN course_categories cat ON c.category_id = cat.id
        LEFT JOIN sub_categories subcat ON c.sub_category_id = subcat.id
        WHERE c.id = ?
      `, [id]);
    } catch (tableErr) {
      if (tableErr.code === 'ER_NO_SUCH_TABLE') {
        [courseRows] = await pool.execute(`
          SELECT c.*, u.name as created_by_name, NULL as category_name, NULL as sub_category_name
          FROM courses c 
          LEFT JOIN users u ON c.created_by = u.id 
          WHERE c.id = ?
        `, [id]);
      } else {
        throw tableErr;
      }
    }

    if (!courseRows || courseRows.length === 0) {
      return res.status(404).json({ success: false, message: 'Course not found' });
    }

    // Related data (best-effort if tables exist)
    let files = [];
    let assignments = [];
    let quizzes = [];

    try {
      const [fileRows] = await pool.execute('SELECT * FROM course_files WHERE course_id = ? ORDER BY created_at DESC', [id]);
      files = fileRows;
    } catch {}

    try {
      const [assignRows] = await pool.execute('SELECT * FROM assignments WHERE course_id = ? ORDER BY created_at DESC', [id]);
      assignments = assignRows;
    } catch {}

    try {
      const [quizRows] = await pool.execute('SELECT * FROM quizzes WHERE course_id = ? ORDER BY id DESC', [id]);
      quizzes = quizRows;
    } catch {}

    res.json({
      success: true,
      course: courseRows[0],
      files,
      assignments,
      quizzes
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching course details' });
  }
});

// Course outline: units with resources, assignments, quizzes
router.get('/courses/:id/outline', async (req, res) => {
  try {
    const { id } = req.params;

    // Course basics
    const [courseRows] = await pool.execute('SELECT * FROM courses WHERE id = ? LIMIT 1', [id]);
    if (!courseRows.length) return res.status(404).json({ success: false, message: 'Course not found' });

    // Units
    const [unitRows] = await pool.execute('SELECT * FROM units WHERE course_id = ? ORDER BY order_index, id', [id]);

    // Children (unit_id may not exist in some schemas; fall back to course-level)
    let resourceRows = [];
    let assignRows = [];
    let quizRows = [];
    try { const [r] = await pool.execute('SELECT * FROM resources WHERE course_id = ?', [id]); resourceRows = r; } catch {}
    try { const [a] = await pool.execute('SELECT * FROM assignments WHERE course_id = ?', [id]); assignRows = a; } catch {}
    try { const [q] = await pool.execute('SELECT * FROM quizzes WHERE course_id = ?', [id]); quizRows = q; } catch {}

    // Group by unit_id if column exists; otherwise attach to first unit or to a pseudo General section
    const unitIdFieldExists = resourceRows.some(r => 'unit_id' in r) || assignRows.some(a => 'unit_id' in a) || quizRows.some(q => 'unit_id' in q);

    const outline = unitRows.map(u => ({
      ...u,
      resources: resourceRows.filter(r => unitIdFieldExists ? r.unit_id === u.id : true),
      assignments: assignRows.filter(a => unitIdFieldExists ? a.unit_id === u.id : true),
      quizzes: quizRows.filter(q => unitIdFieldExists ? q.unit_id === u.id : true)
    }));

    res.json({ success: true, course: courseRows[0], units: outline });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching outline' });
  }
});

// Create a unit
router.post('/courses/:id/units', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, content, order_index } = req.body;
    const [r] = await pool.execute(
      'INSERT INTO units (course_id, title, content, order_index) VALUES (?, ?, ?, ?)',
      [id, title, content || '', order_index || 1]
    );
    res.json({ success: true, unitId: r.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating unit' });
  }
});

// Update a unit
router.put('/units/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, content, order_index } = req.body;
    await pool.execute(
      'UPDATE units SET title = ?, content = ?, order_index = ? WHERE id = ?',
      [title, content || '', order_index || 1, id]
    );
    res.json({ success: true, message: 'Unit updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error updating unit' });
  }
});

// Delete a unit
router.delete('/units/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute('DELETE FROM units WHERE id = ?', [id]);
    res.json({ success: true, message: 'Unit deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error deleting unit' });
  }
});

// Upload a PDF (or file) to a unit (using Cloudinary)
router.post('/units/:unitId/resources', upload.single('file'), async (req, res) => {
  try {
    const { unitId } = req.params;
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

    // Find course for the unit
    const [u] = await pool.execute('SELECT course_id FROM units WHERE id = ? LIMIT 1', [unitId]);
    if (!u.length) return res.status(404).json({ success: false, message: 'Unit not found' });
    const courseId = u[0].course_id;

    // Upload to Cloudinary
    const cloudinaryResult = await uploadToCloudinary(req.file, `lms/courses/${courseId}/units/${unitId}`);
    const cloudinaryUrl = cloudinaryResult.secure_url;

    // Try insert with unit_id if column exists
    try {
      const [r] = await pool.execute(
        'INSERT INTO resources (course_id, title, file_path, uploaded_by, unit_id) VALUES (?, ?, ?, ?, ?)',
        [courseId, req.file.originalname, cloudinaryUrl, 1, unitId]
      );
      return res.json({ success: true, resourceId: r.insertId, url: cloudinaryUrl });
    } catch (e) {
      // fallback without unit_id column
      const [r] = await pool.execute(
        'INSERT INTO resources (course_id, title, file_path, uploaded_by) VALUES (?, ?, ?, ?)',
        [courseId, req.file.originalname, cloudinaryUrl, 1]
      );
      return res.json({ success: true, resourceId: r.insertId, url: cloudinaryUrl });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error uploading resource' });
  }
});

// Update a resource (title only)
router.put('/resources/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title } = req.body;
    
    if (!title || !title.trim()) {
      return res.status(400).json({ success: false, message: 'Title is required' });
    }

    await pool.execute(
      'UPDATE resources SET title = ? WHERE id = ?',
      [title.trim(), id]
    );
    
    res.json({ success: true, message: 'Resource updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error updating resource' });
  }
});

// Delete a resource (from Cloudinary and database)
router.delete('/resources/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // Get resource info including Cloudinary URL
    const [resources] = await pool.execute(
      'SELECT file_path FROM resources WHERE id = ?',
      [id]
    );
    
    if (!resources.length) {
      return res.status(404).json({ success: false, message: 'Resource not found' });
    }
    
    const filePath = resources[0].file_path;
    
    // Delete from Cloudinary if it's a Cloudinary URL
    if (filePath && (filePath.includes('cloudinary.com') || filePath.includes('res.cloudinary.com'))) {
      try {
        // Extract public_id and resource_type from Cloudinary URL
        // Format: https://res.cloudinary.com/{cloud_name}/{resource_type}/upload/v{version}/{public_id}.{format}
        // Or: https://res.cloudinary.com/{cloud_name}/{resource_type}/upload/{public_id}.{format}
        const urlParts = filePath.split('/');
        const uploadIndex = urlParts.findIndex(part => part === 'upload');
        
        if (uploadIndex !== -1 && uploadIndex > 0) {
          // Extract resource_type from URL (it's the part before 'upload')
          const resourceType = urlParts[uploadIndex - 1];
          
          // Validate resource_type (must be one of: image, video, raw, javascript, css)
          const validResourceTypes = ['image', 'video', 'raw', 'javascript', 'css'];
          const finalResourceType = validResourceTypes.includes(resourceType) ? resourceType : 'raw';
          
          // Get everything after 'upload'
          const afterUpload = urlParts.slice(uploadIndex + 1).join('/');
          
          // Remove version number if present (format: v1234567890/public_id.ext)
          let publicId = afterUpload;
          if (afterUpload.startsWith('v') && afterUpload.includes('/')) {
            // Skip version part (v1234567890/)
            publicId = afterUpload.split('/').slice(1).join('/');
          }
          
          // Remove file extension
          const publicIdWithoutExt = publicId.replace(/\.[^/.]+$/, '');
          
          // Delete from Cloudinary with the correct resource type
          const result = await cloudinary.uploader.destroy(publicIdWithoutExt, {
            resource_type: finalResourceType
          });
          console.log('Cloudinary deletion result:', result);
        }
      } catch (cloudinaryErr) {
        console.error('Error deleting from Cloudinary:', cloudinaryErr);
        // Continue with database deletion even if Cloudinary deletion fails
      }
    }
    
    // Delete from database
    await pool.execute('DELETE FROM resources WHERE id = ?', [id]);
    
    res.json({ success: true, message: 'Resource deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error deleting resource' });
  }
});

// Import quiz from GIFT format text for a course (optionally attach to unit)
router.post('/courses/:id/quizzes/import-gift', async (req, res) => {
  try {
    const { id } = req.params; // course id
    const { gift, title, unit_id } = req.body;
    if (!gift || typeof gift !== 'string') return res.status(400).json({ success: false, message: 'gift text required' });

    // Create quiz
    const quizTitle = title || 'Imported Quiz';
    let quizInsert;
    try {
      quizInsert = await pool.execute('INSERT INTO quizzes (course_id, title, created_by, unit_id) VALUES (?, ?, ?, ?)', [id, quizTitle, 1, unit_id || null]);
    } catch (e) {
      // Fallback without unit_id column
      quizInsert = await pool.execute('INSERT INTO quizzes (course_id, title, created_by) VALUES (?, ?, ?)', [id, quizTitle, 1]);
    }
    const quizId = quizInsert[0].insertId;

    // Minimal GIFT parser: supports MC questions with =correct and ~wrong
    const lines = gift.split(/\r?\n/);
    let buffer = '';
    const blocks = [];
    for (const line of lines) {
      if (line.trim() === '' && buffer.trim()) { blocks.push(buffer); buffer = ''; }
      else buffer += line + '\n';
    }
    if (buffer.trim()) blocks.push(buffer);

    for (const block of blocks) {
      const qMatch = block.match(/^(.*)\{([\s\S]*)\}$/m);
      if (!qMatch) continue;
      const questionText = qMatch[1].trim();
      const answersRaw = qMatch[2].trim();
      const parts = answersRaw.split(/\n|(?=\s*[=~])/).map(s => s.trim()).filter(Boolean);
      const options = [];
      let correct = '';
      for (const p of parts) {
        if (p.startsWith('=')) { const text = p.slice(1).trim(); options.push(text); correct = text; }
        else if (p.startsWith('~')) { const text = p.slice(1).trim(); options.push(text); }
      }
      const optionsJson = JSON.stringify(options);
      await pool.execute('INSERT INTO quiz_questions (quiz_id, question, options, correct_answer) VALUES (?, ?, ?, ?)', [quizId, questionText, optionsJson, correct]);
    }

    res.json({ success: true, quizId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error importing GIFT' });
  }
});

// Get quiz with questions
router.get('/quizzes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [quizRows] = await pool.execute('SELECT * FROM quizzes WHERE id = ? LIMIT 1', [id]);
    if (!quizRows.length) return res.status(404).json({ success: false, message: 'Quiz not found' });
    const [qRows] = await pool.execute('SELECT id, question, options, correct_answer FROM quiz_questions WHERE quiz_id = ? ORDER BY id', [id]);
    res.json({ success: true, quiz: quizRows[0], questions: qRows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching quiz' });
  }
});

// Update a quiz (title only)
router.put('/quizzes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title } = req.body;
    
    if (!title || !title.trim()) {
      return res.status(400).json({ success: false, message: 'Title is required' });
    }

    await pool.execute(
      'UPDATE quizzes SET title = ? WHERE id = ?',
      [title.trim(), id]
    );
    
    res.json({ success: true, message: 'Quiz updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error updating quiz' });
  }
});

// Delete a quiz (with cascade delete of questions and submissions)
router.delete('/quizzes/:id', async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const { id } = req.params;
    
    // Check if quiz exists
    const [quizRows] = await connection.execute('SELECT id FROM quizzes WHERE id = ?', [id]);
    if (!quizRows.length) {
      await connection.rollback();
      return res.status(404).json({ success: false, message: 'Quiz not found' });
    }
    
    // Delete quiz submissions (if table exists)
    try {
      await connection.execute('DELETE FROM quiz_submissions WHERE quiz_id = ?', [id]);
    } catch (e) {
      // Table might not exist, continue
    }
    
    // Delete quiz questions
    try {
      await connection.execute('DELETE FROM quiz_questions WHERE quiz_id = ?', [id]);
    } catch (e) {
      // Table might not exist, continue
    }
    
    // Delete the quiz
    await connection.execute('DELETE FROM quizzes WHERE id = ?', [id]);
    
    await connection.commit();
    res.json({ success: true, message: 'Quiz deleted successfully' });
  } catch (err) {
    await connection.rollback();
    console.error(err);
    res.status(500).json({ success: false, message: 'Error deleting quiz' });
  } finally {
    connection.release();
  }
});

// Submit quiz attempt and score
router.post('/quizzes/:id/attempt', async (req, res) => {
  try {
    const { id } = req.params;
    const { student_id, answers } = req.body; // answers: [{question_id, answer}]
    const [qRows] = await pool.execute('SELECT id, correct_answer FROM quiz_questions WHERE quiz_id = ?', [id]);
    const answerMap = new Map(qRows.map((q) => [q.id, q.correct_answer]));
    let correct = 0;
    let total = qRows.length;
    for (const a of (answers || [])) {
      if (String(a.answer).trim() === String(answerMap.get(a.question_id)).trim()) correct++;
    }
    const score = total ? Math.round((correct / total) * 100) : 0;
    const record = { quiz_id: Number(id), student_id: student_id || null, answers: JSON.stringify(answers || []), score };
    try {
      await pool.execute('INSERT INTO quiz_submissions (quiz_id, student_id, answers, score, submitted_at) VALUES (?, ?, ?, ?, NOW())', [record.quiz_id, record.student_id, record.answers, score]);
    } catch (e) {
      // table might not have submitted_at in some schemas
      try { await pool.execute('INSERT INTO quiz_submissions (quiz_id, student_id, answers, score) VALUES (?, ?, ?, ?)', [record.quiz_id, record.student_id, record.answers, score]); } catch {}
    }
    res.json({ success: true, score, total, correct });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error submitting quiz' });
  }
});

// Create course
router.post('/courses', async (req, res) => {
  try {
    const { title, description, status, created_by, category_id, sub_category_id, start_date, end_date } = req.body;
    
    const [result] = await pool.execute(
      'INSERT INTO courses (title, description, status, created_by, category_id, sub_category_id, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [title, description, status || 'Active', created_by, category_id || null, sub_category_id || null, start_date || null, end_date || null]
    );

    res.json({ success: true, message: 'Course created successfully', courseId: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating course' });
  }
});

// Update course
router.put('/courses/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, status, category_id, sub_category_id, start_date, end_date } = req.body;

    await pool.execute(
      'UPDATE courses SET title = ?, description = ?, status = ?, category_id = ?, sub_category_id = ?, start_date = ?, end_date = ? WHERE id = ?',
      [title, description, status, category_id || null, sub_category_id || null, start_date || null, end_date || null, id]
    );

    res.json({ success: true, message: 'Course updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error updating course' });
  }
});

// Delete course (with cascade delete of related records)
router.delete('/courses/:id', async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const { id } = req.params;

    // Delete in order to respect foreign key constraints
    // 1. Delete quiz submissions (if table exists)
    try {
      await connection.execute('DELETE FROM quiz_submissions WHERE quiz_id IN (SELECT id FROM quizzes WHERE course_id = ?)', [id]);
    } catch (e) {}

    // 2. Delete quiz questions (if table exists)
    try {
      await connection.execute('DELETE FROM quiz_questions WHERE quiz_id IN (SELECT id FROM quizzes WHERE course_id = ?)', [id]);
    } catch (e) {}

    // 3. Delete quizzes
    try {
      await connection.execute('DELETE FROM quizzes WHERE course_id = ?', [id]);
    } catch (e) {}

    // 4. Delete assignment submissions (if table exists)
    try {
      await connection.execute('DELETE FROM assignment_submissions WHERE assignment_id IN (SELECT id FROM assignments WHERE course_id = ?)', [id]);
    } catch (e) {}

    // 5. Delete assignments
    try {
      await connection.execute('DELETE FROM assignments WHERE course_id = ?', [id]);
    } catch (e) {}

    // 6. Delete resources (files - only links in DB, actual files in Cloudinary)
    try {
      await connection.execute('DELETE FROM resources WHERE course_id = ?', [id]);
    } catch (e) {}

    // 7. Delete course files (if table exists)
    try {
      await connection.execute('DELETE FROM course_files WHERE course_id = ?', [id]);
    } catch (e) {}

    // 8. Delete units (topics)
    try {
      await connection.execute('DELETE FROM units WHERE course_id = ?', [id]);
    } catch (e) {}

    // 9. Delete course assignments (if table exists)
    try {
      await connection.execute('DELETE FROM course_assignments WHERE course_id = ?', [id]);
    } catch (e) {}

    // 10. Finally, delete the course
    await connection.execute('DELETE FROM courses WHERE id = ?', [id]);

    await connection.commit();
    res.json({ success: true, message: 'Course and all related data deleted successfully' });
  } catch (err) {
    await connection.rollback();
    console.error('Error deleting course:', err);
    res.status(500).json({ success: false, message: 'Error deleting course: ' + err.message });
  } finally {
    connection.release();
  }
});

// Upload course files (using Cloudinary)
router.post('/courses/upload', upload.single('courseFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    const { courseId, fileType } = req.body;
    const fileName = req.file.originalname;

    // Upload to Cloudinary
    const cloudinaryResult = await uploadToCloudinary(req.file, `lms/courses/${courseId}`);
    const cloudinaryUrl = cloudinaryResult.secure_url;

    // Save file info to database (file_path stores Cloudinary URL)
    const [result] = await pool.execute(
      'INSERT INTO course_files (course_id, file_name, file_path, file_type, file_size) VALUES (?, ?, ?, ?, ?)',
      [courseId, fileName, cloudinaryUrl, fileType || 'resource', req.file.size]
    );

    res.json({ 
      success: true, 
      message: 'File uploaded successfully',
      fileId: result.insertId,
      fileName: fileName,
      filePath: cloudinaryUrl,
      url: cloudinaryUrl
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error uploading file' });
  }
});

// Get course files
router.get('/courses/:id/files', async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.execute(
      'SELECT * FROM course_files WHERE course_id = ? ORDER BY created_at DESC',
      [id]
    );
    res.json({ success: true, files: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching course files' });
  }
});

// Backup all courses
router.post('/courses/backup', async (req, res) => {
  try {
    const backupData = {
      courses: [],
      categories: [],
      assignments: [],
      quizzes: [],
      timestamp: new Date().toISOString()
    };

    // Get all courses
    const [courses] = await pool.execute('SELECT * FROM courses');
    backupData.courses = courses;

    // Get categories
    const [categories] = await pool.execute('SELECT * FROM course_categories');
    backupData.categories = categories;

    // Get assignments
    const [assignments] = await pool.execute('SELECT * FROM assignments');
    backupData.assignments = assignments;

    // Get quizzes
    const [quizzes] = await pool.execute('SELECT * FROM quizzes');
    backupData.quizzes = quizzes;

    // Save backup to file
    const backupPath = `backups/course-backup-${Date.now()}.json`;
    if (!fs.existsSync('backups')) {
      fs.mkdirSync('backups', { recursive: true });
    }
    
    fs.writeFileSync(backupPath, JSON.stringify(backupData, null, 2));

    res.json({ 
      success: true, 
      message: 'Backup created successfully',
      backupPath: backupPath,
      coursesCount: courses.length
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating backup' });
  }
});

// Restore courses from backup (.mbz or .json files)
// NOTE: Files are uploaded to memory, then processed. No local storage.
router.post('/courses/restore', upload.single('backupFile'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No backup file uploaded' });
    }

    // Since we use memory storage, we work with the buffer directly
    const fileBuffer = req.file.buffer;
    const fileName = req.file.originalname;
    const fileExtension = path.extname(fileName).toLowerCase();

    let backupData;

    if (fileExtension === '.mbz') {
      // Handle Moodle .mbz file - write buffer to temp file for AdmZip
      const tempPath = path.join(__dirname, '../temp', `backup-${Date.now()}.mbz`);
      if (!fs.existsSync(path.dirname(tempPath))) {
        fs.mkdirSync(path.dirname(tempPath), { recursive: true });
      }
      fs.writeFileSync(tempPath, fileBuffer);
      try {
        backupData = await handleMoodleBackup(tempPath);
      } finally {
        // Clean up temp file
        if (fs.existsSync(tempPath)) {
          fs.unlinkSync(tempPath);
        }
      }
    } else if (fileExtension === '.json') {
      // Handle JSON backup file - parse from buffer
      backupData = JSON.parse(fileBuffer.toString('utf8'));
    } else {
      return res.status(400).json({ success: false, message: 'Unsupported file format. Please upload .mbz or .json files.' });
    }

    // Helper: ensure category by name, return id
    async function ensureCategoryId(name, description) {
      if (!name) return null;
      const [found] = await pool.execute('SELECT id FROM course_categories WHERE name = ? LIMIT 1', [name]);
      if (found.length > 0) return found[0].id;
      const [ins] = await pool.execute('INSERT INTO course_categories (name, description) VALUES (?, ?)', [name, description || '' ]);
      return ins.insertId;
    }

    // Build map from temp course ids (if provided) to new ids
    const courseIdMap = new Map();

    // Restore categories and courses
    if (backupData.courses && backupData.courses.length > 0) {
      for (const course of backupData.courses) {
        const categoryId = course.category_name
          ? await ensureCategoryId(course.category_name, course.category_description)
          : (course.category_id || null);

        const [result] = await pool.execute(
          'INSERT INTO courses (title, description, status, created_by, category_id) VALUES (?, ?, ?, ?, ?)',
          [course.title, course.description, course.status || 'Active', course.created_by || 1, categoryId || null]
        );
        // If the input had an id, map it to the new auto id
        if (course.id) courseIdMap.set(course.id, result.insertId);
        // Also store mapping by title in case ids were missing
        courseIdMap.set(course.title, result.insertId);
      }
    }

    // Resolve helper for course_id
    function resolveCourseId(ref) {
      if (!ref) return null;
      if (courseIdMap.has(ref)) return courseIdMap.get(ref);
      // try by title string
      if (typeof ref === 'string' && courseIdMap.has(ref)) return courseIdMap.get(ref);
      return null;
    }

    // Restore assignments
    if (backupData.assignments && backupData.assignments.length > 0) {
      for (const assignment of backupData.assignments) {
        const cid = resolveCourseId(assignment.course_id) || resolveCourseId(assignment.course_title) || null;
        if (!cid) continue;
        await pool.execute(
          'INSERT INTO assignments (course_id, title, description, due_date, created_by) VALUES (?, ?, ?, ?, ?)',
          [cid, assignment.title, assignment.description, assignment.due_date || null, assignment.created_by || 1]
        );
      }
    }

    // Restore quizzes
    if (backupData.quizzes && backupData.quizzes.length > 0) {
      for (const quiz of backupData.quizzes) {
        const cid = resolveCourseId(quiz.course_id) || resolveCourseId(quiz.course_title) || null;
        if (!cid) continue;
        await pool.execute(
          'INSERT INTO quizzes (course_id, title, created_by) VALUES (?, ?, ?)',
          [cid, quiz.title, quiz.created_by || 1]
        );
      }
    }

    // No cleanup needed - file was in memory only

    res.json({ 
      success: true, 
      message: 'Courses restored successfully',
      restoredCourses: backupData.courses ? backupData.courses.length : 0,
      restoredCategories: backupData.categories ? backupData.categories.length : 0,
      fileType: fileExtension === '.mbz' ? 'Moodle Backup' : 'JSON Backup'
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error restoring backup' });
  }
});

// Student assignment submission (file upload using Cloudinary)
router.post('/assignments/:id/submit', upload.single('submission'), async (req, res) => {
  try {
    const { id } = req.params;
    const { student_id } = req.body; // In production, derive from JWT
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

    // Upload to Cloudinary
    const cloudinaryResult = await uploadToCloudinary(req.file, `lms/assignments/${id}/submissions`);
    const cloudinaryUrl = cloudinaryResult.secure_url;

    await pool.execute(
      'INSERT INTO assignment_submissions (assignment_id, student_id, file_path, submitted_at) VALUES (?, ?, ?, NOW())',
      [id, student_id, cloudinaryUrl]
    );
    res.json({ success: true, url: cloudinaryUrl });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error submitting assignment' });
  }
});

// Enroll student(s) in course(s)
router.post('/enrollments', async (req, res) => {
  try {
    const { student_ids, course_id, assigned_by } = req.body;
    
    if (!student_ids || !Array.isArray(student_ids) || student_ids.length === 0) {
      return res.status(400).json({ success: false, message: 'Student IDs array is required' });
    }
    
    if (!course_id) {
      return res.status(400).json({ success: false, message: 'Course ID is required' });
    }

    // Check if course exists
    const [courseCheck] = await pool.execute('SELECT id FROM courses WHERE id = ?', [course_id]);
    if (courseCheck.length === 0) {
      return res.status(404).json({ success: false, message: 'Course not found' });
    }

    const enrolled = [];
    const alreadyEnrolled = [];
    const errors = [];

    for (const student_id of student_ids) {
      try {
        // Check if student exists and is actually a student (role_id = 4)
        const [studentCheck] = await pool.execute('SELECT id, role_id FROM users WHERE id = ?', [student_id]);
        if (studentCheck.length === 0) {
          errors.push({ student_id, error: 'Student not found' });
          continue;
        }
        if (studentCheck[0].role_id !== 4) {
          errors.push({ student_id, error: 'User is not a student' });
          continue;
        }

        // Check if already enrolled
        const [existing] = await pool.execute(
          'SELECT id FROM course_assignments WHERE student_id = ? AND course_id = ?',
          [student_id, course_id]
        );

        if (existing.length > 0) {
          alreadyEnrolled.push(student_id);
          continue;
        }

        // Enroll student
        await pool.execute(
          'INSERT INTO course_assignments (course_id, student_id, assigned_by, status) VALUES (?, ?, ?, ?)',
          [course_id, student_id, assigned_by || null, 'In Progress']
        );
        enrolled.push(student_id);
      } catch (err) {
        errors.push({ student_id, error: err.message });
      }
    }

    res.json({
      success: true,
      message: `Enrollment completed. ${enrolled.length} enrolled, ${alreadyEnrolled.length} already enrolled, ${errors.length} errors`,
      enrolled,
      alreadyEnrolled,
      errors
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error enrolling students' });
  }
});

// Unenroll student from course
router.delete('/enrollments/:courseId/:studentId', async (req, res) => {
  try {
    const { courseId, studentId } = req.params;

    const [result] = await pool.execute(
      'DELETE FROM course_assignments WHERE course_id = ? AND student_id = ?',
      [courseId, studentId]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Enrollment not found' });
    }

    res.json({ success: true, message: 'Student unenrolled successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error unenrolling student' });
  }
});

// Get enrolled students for a course
router.get('/courses/:courseId/enrollments', async (req, res) => {
  try {
    const { courseId } = req.params;

    const [rows] = await pool.execute(`
      SELECT u.id, u.name, u.email, ca.status, ca.created_at as enrolled_at, ca.assigned_by
      FROM course_assignments ca
      JOIN users u ON ca.student_id = u.id
      WHERE ca.course_id = ?
      ORDER BY u.name
    `, [courseId]);

    res.json({ success: true, students: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching enrolled students' });
  }
});

// Get all students (for enrollment dropdown)
router.get('/students', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT id, name, email
      FROM users
      WHERE role_id = 4
      ORDER BY name
    `);
    res.json({ success: true, students: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching students' });
  }
});

// Handle Moodle .mbz file (extract and parse)
async function handleMoodleBackup(filePath) {
  try {
    const backupData = {
      courses: [],
      categories: [],
      assignments: [],
      quizzes: [],
      timestamp: new Date().toISOString()
    };

    // Extract .mbz file (it's a ZIP file)
    const zip = new AdmZip(filePath);
    const zipEntries = zip.getEntries();

    // Look for course.xml file in the backup
    let courseXml = null;
    let moodleBackupXml = null;

    for (let entry of zipEntries) {
      if (entry.entryName.includes('course.xml')) {
        courseXml = entry.getData().toString('utf8');
      }
      if (entry.entryName.includes('moodle_backup.xml')) {
        moodleBackupXml = entry.getData().toString('utf8');
      }
    }

    // Extract course information from XML
    let courseTitle = 'Imported Moodle Course';
    let courseDescription = 'Course imported from Moodle backup';
    let courseShortName = 'moodle-course';

    if (courseXml) {
      // Simple XML parsing to extract course info
      const titleMatch = courseXml.match(/<fullname><!\[CDATA\[(.*?)\]\]><\/fullname>/);
      const descMatch = courseXml.match(/<summary><!\[CDATA\[(.*?)\]\]><\/summary>/);
      const shortMatch = courseXml.match(/<shortname><!\[CDATA\[(.*?)\]\]><\/shortname>/);

      if (titleMatch) courseTitle = titleMatch[1];
      if (descMatch) courseDescription = descMatch[1];
      if (shortMatch) courseShortName = shortMatch[1];
    }

    // Create course from extracted data
    backupData.courses.push({
      id: Date.now(),
      title: courseTitle,
      description: courseDescription,
      status: 'Active',
      created_by: 1, // Default to admin
      category_id: 1 // Default to Programming category
    });

    // Create a category for Moodle imports
    backupData.categories.push({
      id: Date.now() + 1,
      name: 'Moodle Imports',
      description: 'Courses imported from Moodle backup files'
    });

    // Extract assignments and quizzes if available
    if (courseXml) {
      // Look for assignment activities
      const assignmentMatches = courseXml.match(/<activity.*?type="assign".*?<\/activity>/gs);
      if (assignmentMatches) {
        assignmentMatches.forEach((match, index) => {
          const nameMatch = match.match(/<name><!\[CDATA\[(.*?)\]\]><\/name>/);
          const descMatch = match.match(/<intro><!\[CDATA\[(.*?)\]\]><\/intro>/);
          
          backupData.assignments.push({
            id: Date.now() + index + 100,
            course_id: Date.now(),
            title: nameMatch ? nameMatch[1] : `Assignment ${index + 1}`,
            description: descMatch ? descMatch[1] : 'Imported from Moodle',
            due_date: null,
            created_by: 1
          });
        });
      }

      // Look for quiz activities
      const quizMatches = courseXml.match(/<activity.*?type="quiz".*?<\/activity>/gs);
      if (quizMatches) {
        quizMatches.forEach((match, index) => {
          const nameMatch = match.match(/<name><!\[CDATA\[(.*?)\]\]><\/name>/);
          const descMatch = match.match(/<intro><!\[CDATA\[(.*?)\]\]><\/intro>/);
          
          backupData.quizzes.push({
            id: Date.now() + index + 200,
            course_id: Date.now(),
            title: nameMatch ? nameMatch[1] : `Quiz ${index + 1}`,
            created_by: 1
          });
        });
      }
    }

    return backupData;
  } catch (error) {
    console.error('Error parsing .mbz file:', error);
    
    // Fallback: create basic course from filename
    const fileName = path.basename(filePath, '.mbz');
    const courseTitle = fileName.replace(/[_-]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

    return {
      courses: [{
        id: Date.now(),
        title: courseTitle,
        description: `Imported from Moodle backup: ${fileName}`,
        status: 'Active',
        created_by: 1,
        category_id: 1
      }],
      categories: [{
        id: 1,
        name: 'Moodle Imports',
        description: 'Courses imported from Moodle backup files'
      }],
      assignments: [],
      quizzes: [],
      timestamp: new Date().toISOString()
    };
  }
}

// ===============================
// ASSIGNMENT MANAGEMENT
// ===============================

// Get all assignments
router.get('/assignments', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT a.*, c.title as course_title, u.name as created_by_name 
      FROM assignments a 
      LEFT JOIN courses c ON a.course_id = c.id 
      LEFT JOIN users u ON a.created_by = u.id 
      ORDER BY a.created_at DESC
    `);
    res.json({ success: true, assignments: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching assignments' });
  }
});

// Create assignment
router.post('/assignments', async (req, res) => {
  try {
    const { course_id, title, description, due_date, created_by } = req.body;
    
    const [result] = await pool.execute(
      'INSERT INTO assignments (course_id, title, description, due_date, created_by) VALUES (?, ?, ?, ?, ?)',
      [course_id, title, description, due_date, created_by]
    );

    res.json({ success: true, message: 'Assignment created successfully', assignmentId: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating assignment' });
  }
});

// ===============================
// QUIZ MANAGEMENT
// ===============================

// ==================== TUTOR ENDPOINTS ====================

// Get tutor's courses (all courses - tutors can see and manage all courses)
router.get('/tutor/:tutorId/courses', async (req, res) => {
  try {
    const { tutorId } = req.params;
    // Tutors can see all courses (same as admin), but with stats for their context
    const [rows] = await pool.execute(`
      SELECT c.*, 
        u.name as created_by_name,
        cat.name as category_name,
        subcat.name as sub_category_name,
        COUNT(DISTINCT ca.student_id) as student_count,
        COUNT(DISTINCT a.id) as assignment_count,
        COUNT(DISTINCT q.id) as quiz_count
      FROM courses c
      LEFT JOIN users u ON c.created_by = u.id
      LEFT JOIN course_categories cat ON c.category_id = cat.id
      LEFT JOIN sub_categories subcat ON c.sub_category_id = subcat.id
      LEFT JOIN course_assignments ca ON c.id = ca.course_id
      LEFT JOIN assignments a ON c.id = a.course_id
      LEFT JOIN quizzes q ON c.id = q.course_id
      GROUP BY c.id
      ORDER BY c.created_at DESC
    `);
    res.json({ success: true, courses: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching tutor courses' });
  }
});

// Get students in tutor's courses (all students - tutors can see all students)
router.get('/tutor/:tutorId/students', async (req, res) => {
  try {
    const { tutorId } = req.params;
    // Tutors can see all students (both enrolled and not enrolled)
    // Use LEFT JOIN to include students even if they're not enrolled in any course
    const [rows] = await pool.execute(`
      SELECT DISTINCT 
        u.id, 
        u.name, 
        u.email, 
        c.id as course_id, 
        c.title as course_title
      FROM users u
      LEFT JOIN course_assignments ca ON u.id = ca.student_id
      LEFT JOIN courses c ON ca.course_id = c.id
      WHERE u.role_id = 4
      ORDER BY u.name, c.title
    `);
    res.json({ success: true, students: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching students' });
  }
});

// Get assignments for tutor's courses (all assignments in all courses)
router.get('/tutor/:tutorId/assignments', async (req, res) => {
  try {
    const { tutorId } = req.params;
    // Tutors can see all assignments in all courses
    const [rows] = await pool.execute(`
      SELECT a.*, c.title as course_title,
        COUNT(DISTINCT asub.id) as submission_count,
        COUNT(DISTINCT CASE WHEN asub.grade IS NOT NULL THEN asub.id END) as graded_count
      FROM assignments a
      JOIN courses c ON a.course_id = c.id
      LEFT JOIN assignment_submissions asub ON a.id = asub.assignment_id
      GROUP BY a.id
      ORDER BY a.due_date DESC, a.created_at DESC
    `);
    res.json({ success: true, assignments: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching assignments' });
  }
});

// Get quizzes for tutor's courses (all quizzes in all courses)
router.get('/tutor/:tutorId/quizzes', async (req, res) => {
  try {
    const { tutorId } = req.params;
    // Tutors can see all quizzes in all courses
    const [rows] = await pool.execute(`
      SELECT q.*, c.title as course_title,
        COUNT(DISTINCT qs.id) as submission_count
      FROM quizzes q
      JOIN courses c ON q.course_id = c.id
      LEFT JOIN quiz_submissions qs ON q.id = qs.quiz_id
      GROUP BY q.id
      ORDER BY q.created_at DESC
    `);
    res.json({ success: true, quizzes: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching quizzes' });
  }
});

// Get assignment submissions for grading (tutors can grade all assignments)
router.get('/tutor/:tutorId/assignments/:assignmentId/submissions', async (req, res) => {
  try {
    const { tutorId, assignmentId } = req.params;
    // Tutors can see submissions for all assignments
    
    const [rows] = await pool.execute(`
      SELECT asub.*, u.name as student_name, u.email as student_email, a.title as assignment_title
      FROM assignment_submissions asub
      JOIN assignments a ON asub.assignment_id = a.id
      JOIN users u ON asub.student_id = u.id
      WHERE asub.assignment_id = ?
      ORDER BY asub.submitted_at DESC
    `, [assignmentId]);
    res.json({ success: true, submissions: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching submissions' });
  }
});

// Grade assignment submission (tutors can grade all submissions)
router.put('/tutor/assignments/submissions/:submissionId/grade', async (req, res) => {
  try {
    const { submissionId } = req.params;
    const { grade, feedback } = req.body;
    // Tutors can grade all assignment submissions
    
    await pool.execute(
      'UPDATE assignment_submissions SET grade = ?, feedback = ? WHERE id = ?',
      [grade, feedback || '', submissionId]
    );
    res.json({ success: true, message: 'Grade updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error updating grade' });
  }
});

// Get quiz submissions for tutor's quizzes (tutors can see all quiz submissions)
router.get('/tutor/:tutorId/quizzes/:quizId/submissions', async (req, res) => {
  try {
    const { tutorId, quizId } = req.params;
    // Tutors can see submissions for all quizzes
    
    const [rows] = await pool.execute(`
      SELECT qs.*, u.name as student_name, u.email as student_email, q.title as quiz_title
      FROM quiz_submissions qs
      JOIN quizzes q ON qs.quiz_id = q.id
      JOIN users u ON qs.student_id = u.id
      WHERE qs.quiz_id = ?
      ORDER BY qs.submitted_at DESC
    `, [quizId]);
    res.json({ success: true, submissions: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching quiz submissions' });
  }
});

// Get tutor dashboard stats (all courses, students, assignments, quizzes)
router.get('/tutor/:tutorId/stats', async (req, res) => {
  try {
    const { tutorId } = req.params;
    // Tutors can see stats for all courses (same as admin view)
    const [courseCount] = await pool.execute('SELECT COUNT(*) as count FROM courses', []);
    const [studentCount] = await pool.execute(`
      SELECT COUNT(DISTINCT ca.student_id) as count
      FROM course_assignments ca
    `);
    const [assignmentCount] = await pool.execute('SELECT COUNT(*) as count FROM assignments', []);
    const [quizCount] = await pool.execute('SELECT COUNT(*) as count FROM quizzes', []);
    const [pendingGrading] = await pool.execute(`
      SELECT COUNT(*) as count FROM assignment_submissions
      WHERE grade IS NULL
    `);
    
    res.json({
      success: true,
      stats: {
        courses: courseCount[0].count,
        students: studentCount[0].count,
        assignments: assignmentCount[0].count,
        quizzes: quizCount[0].count,
        pendingGrading: pendingGrading[0].count
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching stats' });
  }
});

// Get all quizzes
router.get('/quizzes', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT q.*, c.title as course_title, u.name as created_by_name 
      FROM quizzes q 
      LEFT JOIN courses c ON q.course_id = c.id 
      LEFT JOIN users u ON q.created_by = u.id 
      ORDER BY q.created_at DESC
    `);
    res.json({ success: true, quizzes: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching quizzes' });
  }
});

// Create quiz
router.post('/quizzes', async (req, res) => {
  try {
    const { course_id, title, created_by } = req.body;
    
    const [result] = await pool.execute(
      'INSERT INTO quizzes (course_id, title, created_by) VALUES (?, ?, ?)',
      [course_id, title, created_by]
    );

    res.json({ success: true, message: 'Quiz created successfully', quizId: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating quiz' });
  }
});

// ===============================
// ANALYTICS & REPORTS
// ===============================

// Get dashboard statistics
router.get('/stats', async (req, res) => {
  try {
    // Get user counts by role
    const [userStats] = await pool.execute(`
      SELECT r.name as role, COUNT(u.id) as count 
      FROM roles r 
      LEFT JOIN users u ON r.id = u.role_id 
      GROUP BY r.id, r.name
    `);

    // Get course stats
    const [courseStats] = await pool.execute(`
      SELECT 
        COUNT(*) as total_courses,
        SUM(CASE WHEN status = 'Active' THEN 1 ELSE 0 END) as active_courses
      FROM courses
    `);

    // Get assignment stats
    const [assignmentStats] = await pool.execute(`
      SELECT COUNT(*) as total_assignments FROM assignments
    `);

    // Get quiz stats
    const [quizStats] = await pool.execute(`
      SELECT COUNT(*) as total_quizzes FROM quizzes
    `);

    res.json({
      success: true,
      stats: {
        users: userStats,
        courses: courseStats[0],
        assignments: assignmentStats[0],
        quizzes: quizStats[0]
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching statistics' });
  }
});

// ===============================
// FORUM MANAGEMENT
// ===============================

// Get all forums
router.get('/forums', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT f.*, c.title as course_title, u.name as created_by_name 
      FROM forums f 
      LEFT JOIN courses c ON f.course_id = c.id 
      LEFT JOIN users u ON f.created_by = u.id 
      ORDER BY f.created_at DESC
    `);
    res.json({ success: true, forums: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching forums' });
  }
});

// ===============================
// CERTIFICATE & BADGE MANAGEMENT
// ===============================

// Get all certificates
router.get('/certificates', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT cert.*, u.name as student_name, c.title as course_title 
      FROM certificates cert 
      LEFT JOIN users u ON cert.student_id = u.id 
      LEFT JOIN courses c ON cert.course_id = c.id 
      ORDER BY cert.issued_at DESC
    `);
    res.json({ success: true, certificates: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error fetching certificates' });
  }
});

// Create certificate
router.post('/certificates', async (req, res) => {
  try {
    const { student_id, course_id, title } = req.body;
    
    const [result] = await pool.execute(
      'INSERT INTO certificates (student_id, course_id, title) VALUES (?, ?, ?)',
      [student_id, course_id, title]
    );

    res.json({ success: true, message: 'Certificate created successfully', certificateId: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error creating certificate' });
  }
});

// Proxy endpoint to serve files (PDFs, videos) from Cloudinary (bypasses CORS and auth issues)
router.get('/proxy-pdf', async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) {
      return res.status(400).json({ success: false, message: 'URL parameter required' });
    }

    // Decode the URL
    let fileUrl = decodeURIComponent(url);
    
    // Determine file type from URL
    const isVideo = fileUrl.includes('/video/') || fileUrl.includes('.mp4') || fileUrl.includes('.mov') || fileUrl.includes('.avi');
    const isPdf = fileUrl.includes('.pdf') || fileUrl.includes('/raw/');
    
    // For Cloudinary URLs, ensure we're using the correct format
    // If it's an image URL but should be raw, convert it
    if (fileUrl.includes('cloudinary.com') && fileUrl.includes('/image/upload/') && fileUrl.endsWith('.pdf')) {
      fileUrl = fileUrl.replace('/image/upload/', '/raw/upload/');
    }
    
    // Determine if it's http or https
    const client = fileUrl.startsWith('https') ? https : http;
    
    // Fetch the file from Cloudinary
    client.get(fileUrl, (response) => {
      // Handle errors
      if (response.statusCode === 401 || response.statusCode === 403) {
        console.error('File access denied (401/403). File may not be publicly accessible:', fileUrl);
        return res.status(401).json({ 
          success: false, 
          message: 'File is not publicly accessible. Please ensure the file is set to public in Cloudinary.' 
        });
      }
      
      if (response.statusCode !== 200) {
        console.error('Failed to fetch file:', response.statusCode, fileUrl);
        return res.status(response.statusCode).json({ 
          success: false, 
          message: `Failed to fetch file: ${response.statusCode}` 
        });
      }
      
      // Set proper headers based on file type
      if (isVideo) {
        res.setHeader('Content-Type', 'video/mp4');
        res.setHeader('Accept-Ranges', 'bytes'); // Enable range requests for video seeking
      } else if (isPdf) {
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'inline; filename="document.pdf"');
      } else {
        // Default to binary
        res.setHeader('Content-Type', 'application/octet-stream');
      }
      
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Range');
      res.setHeader('Cache-Control', 'public, max-age=3600');
      
      // Support range requests for video streaming
      if (isVideo && req.headers.range) {
        const range = req.headers.range;
        const parts = range.replace(/bytes=/, '').split('-');
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : response.headers['content-length'] - 1;
        const chunksize = (end - start) + 1;
        
        res.writeHead(206, {
          'Content-Range': `bytes ${start}-${end}/${response.headers['content-length']}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunksize,
          'Content-Type': 'video/mp4',
        });
        
        // Note: For proper range support, we'd need to handle the stream differently
        // For now, pipe the full response
        response.pipe(res);
      } else {
        // Pipe the file data to response
        response.pipe(res);
      }
    }).on('error', (error) => {
      console.error('Error proxying file:', error);
      res.status(500).json({ success: false, message: 'Error fetching file: ' + error.message });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Error proxying file' });
  }
});

module.exports = router;
