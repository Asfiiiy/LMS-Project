const express = require('express');
const router = express.Router();
const pool = require('../config/db'); // MySQL pool

// Get all courses for a specific student
router.get('/:studentId', async (req, res) => {
  const { studentId } = req.params;
  try {
    const [rows] = await pool.execute(
      `SELECT c.id, c.title, c.description, sc.status
       FROM courses c
       JOIN course_assignments sc ON c.id = sc.course_id
       WHERE sc.student_id = ?`,
      [studentId]
    );

    res.json({ success: true, courses: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
