-- Add start_date and end_date to courses table
ALTER TABLE courses 
ADD COLUMN start_date DATE NULL,
ADD COLUMN end_date DATE NULL;

-- Create sub_categories table
CREATE TABLE IF NOT EXISTS sub_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES course_categories(id) ON DELETE CASCADE,
    UNIQUE KEY unique_subcategory (category_id, name)
);

-- Add sub_category_id to courses table
ALTER TABLE courses 
ADD COLUMN sub_category_id INT NULL,
ADD FOREIGN KEY (sub_category_id) REFERENCES sub_categories(id) ON DELETE SET NULL;

-- Update resources table to store Cloudinary URLs (file_path will now store Cloudinary URL)
-- No change needed - file_path column already exists and can store URLs

-- Update assignment_submissions to store Cloudinary URLs
-- No change needed - file_path column already exists and can store URLs

-- Add unit_id to resources, assignments, and quizzes if not exists
ALTER TABLE resources ADD COLUMN IF NOT EXISTS unit_id INT NULL;
ALTER TABLE resources ADD FOREIGN KEY IF NOT EXISTS (unit_id) REFERENCES units(id) ON DELETE SET NULL;

ALTER TABLE assignments ADD COLUMN IF NOT EXISTS unit_id INT NULL;
ALTER TABLE assignments ADD FOREIGN KEY IF NOT EXISTS (unit_id) REFERENCES units(id) ON DELETE SET NULL;

ALTER TABLE quizzes ADD COLUMN IF NOT EXISTS unit_id INT NULL;
ALTER TABLE quizzes ADD FOREIGN KEY IF NOT EXISTS (unit_id) REFERENCES units(id) ON DELETE SET NULL;

