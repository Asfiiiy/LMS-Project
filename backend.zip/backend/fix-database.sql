-- Create course_categories table
CREATE TABLE IF NOT EXISTS course_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create course_files table
CREATE TABLE IF NOT EXISTS course_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50) DEFAULT 'resource',
    file_size BIGINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- Add category_id column to courses table
ALTER TABLE courses ADD COLUMN category_id INT;
ALTER TABLE courses ADD FOREIGN KEY (category_id) REFERENCES course_categories(id);

-- Insert sample categories
INSERT INTO course_categories (id, name, description) VALUES 
(1, 'Programming', 'Programming and software development courses'),
(2, 'Mathematics', 'Mathematics and statistics courses'),
(3, 'Science', 'Science and research courses'),
(4, 'Business', 'Business and management courses'),
(5, 'Languages', 'Language learning courses'),
(6, 'Arts', 'Arts and creative courses');
