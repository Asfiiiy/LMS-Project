// backend/config/db.js
const mysql = require('mysql2/promise'); // Using promise version

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root', // your MySQL user
  password: process.env.DB_PASSWORD || '', // your MySQL password
  database: process.env.DB_NAME || 'db_lms', // your MySQL database
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Test the connection
(async () => {
  try {
    const connection = await pool.getConnection();
    console.log('MySQL connected successfully!');
    connection.release(); // release the connection back to pool
  } catch (err) {
    console.error('MySQL connection error:', err);
  }
})();

module.exports = pool;
